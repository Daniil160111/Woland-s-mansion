window.SettingsBlock = {
  assets: {
    bg: 'https://raw.githubusercontent.com/Daniil160111/Woland-s-mansion/refs/heads/main/title.jpg',
    trackSettings: 'https://github.com/Daniil160111/Woland-s-mansion/raw/refs/heads/main/%D0%9D%D0%B0%D1%81%D1%82%D1%80%D0%BE%D0%B9%D0%BA%D0%B8,%20%D0%B7%D0%B0%D0%BF%D0%B8%D1%81%D0%B8,%20%D0%BA%D0%BE%D0%BC%D0%BD%D0%B0%D1%82%D1%8B.mp3',
    sfxSave: 'https://github.com/Daniil160111/Woland-s-mansion/raw/refs/heads/main/%D0%9A%D0%BD%D0%BE%D0%BF%D0%BA%D0%B0.wav',
    sfxBack: 'https://github.com/Daniil160111/Woland-s-mansion/raw/refs/heads/main/%D0%9A%D0%BD%D0%BE%D0%BF%D0%BA%D0%B0%20%D0%BD%D0%B0%D0%B7%D0%B0%D0%B4.wav',
    sfxClear: 'https://github.com/Daniil160111/Woland-s-mansion/raw/refs/heads/main/%D0%A1%D0%B1%D1%80%D0%BE%D1%81.mp3'
  },

  styles: `
    .settings-screen {
      position: fixed;
      top: 0; left: 0;
      width: 100vw; height: 100vh;
      background: #000;
      display: flex;
      align-items: center;
      justify-content: center;
      z-index: 1000;
      opacity: 0;
      transition: opacity 0.8s ease;
    }
    .settings-screen.show { opacity: 1; }
    .settings-screen.hide { opacity: 0; pointer-events: none; }

    .settings-bg {
      position: absolute;
      top: 0; left: 0;
      width: 100%; height: 100%;
      object-fit: cover;
      opacity: 0.15;
    }

    .settings-box {
      position: relative;
      z-index: 1;
      background: rgba(12, 10, 26, 0.92);
      border: 2px solid rgba(110, 90, 180, 0.3);
      border-radius: 20px;
      padding: 30px 25px;
      width: 90%;
      max-width: 380px;
      box-shadow: 0 20px 60px rgba(0,0,0,0.9);
    }

    .settings-title {
      color: #e2d9f3;
      font-size: 1.6rem;
      font-weight: bold;
      text-align: center;
      margin-bottom: 22px;
      font-family: sans-serif;
    }

    .s-group { margin-bottom: 18px; }
    .s-label {
      color: #b0a8cc;
      font-size: 0.85rem;
      font-weight: 600;
      display: block;
      margin-bottom: 5px;
      font-family: sans-serif;
    }

    .s-input {
      width: 100%;
      padding: 10px 14px;
      background: rgba(30, 25, 60, 0.8);
      border: 1.5px solid rgba(110, 90, 180, 0.3);
      border-radius: 10px;
      color: #e2d9f3;
      font-size: 1rem;
      outline: none;
      box-sizing: border-box;
      font-family: sans-serif;
    }
    .s-input:focus { border-color: #bfa0ff; }

    .s-buttons {
      display: flex;
      gap: 10px;
      margin-top: 18px;
      flex-wrap: wrap;
    }

    .s-btn {
      padding: 12px 16px;
      border-radius: 12px;
      border: 1.8px solid rgba(110, 90, 180, 0.5);
      background: rgba(12, 10, 26, 0.78);
      color: #e2d9f3;
      font-size: 1rem;
      font-weight: bold;
      cursor: pointer;
      flex: 1;
      min-width: 100px;
      text-align: center;
      font-family: sans-serif;
      transition: all 0.1s;
    }
    .s-btn:active { transform: scale(0.95); }

    .s-btn-save {
      border-color: rgba(80, 200, 120, 0.5);
      color: #8affb0;
    }
    .s-btn-save:active { background: rgba(30, 100, 50, 0.8); }

    .s-btn-back {
      border-color: rgba(180, 70, 70, 0.5);
      color: #f3d9d9;
    }
    .s-btn-back:active { background: rgba(140, 35, 45, 0.8); }

    .s-btn-danger {
      border-color: rgba(200, 50, 50, 0.6);
      color: #ff9a9a;
    }
    .s-btn-danger:active { background: rgba(160, 30, 30, 0.8); }

    .s-status {
      color: #80b0a0;
      font-size: 0.8rem;
      text-align: center;
      margin-top: 12px;
      min-height: 20px;
      font-family: sans-serif;
    }
  `,

  audio: null,
  isClosing: false,

  init() {
    this.isClosing = false;
    const sm = window.settingsManager;

    if (this.audio) {
      try { this.audio.pause(); } catch(e) {}
      this.audio = null;
    }

    const app = document.getElementById('app') || document.body;
    app.innerHTML = '';

    // Стили
    const style = document.createElement('style');
    style.textContent = this.styles;
    document.head.appendChild(style);

    // Контейнер
    const container = document.createElement('div');
    container.className = 'settings-screen';
    container.id = 'settings-container';
    container.innerHTML = `
      <img src="${this.assets.bg}" class="settings-bg">
      <div class="settings-box">
        <div class="settings-title">⚙️ Настройки</div>

        <div class="s-group">
          <label class="s-label">👤 Имя игрока</label>
          <input class="s-input" id="s-name" maxlength="20" placeholder="Введите имя">
        </div>

        <div class="s-buttons">
          <button class="s-btn s-btn-save" id="s-save">💾 Сохранить</button>
          <button class="s-btn s-btn-back" id="s-back">↩ Назад</button>
        </div>

        <div class="s-buttons">
          <button class="s-btn s-btn-danger" id="s-clear" style="flex:1;">🗑️ Стереть данные</button>
        </div>

        <div class="s-status" id="s-status"></div>
      </div>
    `;
    app.appendChild(container);

    // Загружаем имя
    document.getElementById('s-name').value = sm.getName();

    // Запускаем музыку
    this.playMusic();

    // Показываем с задержкой
    setTimeout(() => container.classList.add('show'), 300);

    // === ОБРАБОТЧИКИ ===
    document.getElementById('s-save').addEventListener('click', () => this.save());
    document.getElementById('s-back').addEventListener('click', () => this.back());
    document.getElementById('s-clear').addEventListener('click', () => this.clear());
  },

  save() {
    const sm = window.settingsManager;
    const name = document.getElementById('s-name').value.trim() || sm.generateGuestName();
    sm.setName(name);

    const status = document.getElementById('s-status');
    status.textContent = '✅ Имя сохранено!';
    status.style.color = '#8affb0';
    setTimeout(() => status.textContent = '', 2000);

    this.playSfx(this.assets.sfxSave);
  },

  clear() {
    if (this.isClosing) return;
    const status = document.getElementById('s-status');
    status.textContent = '⚠️ Удаление данных...';
    status.style.color = '#ff8a8a';
    this.playSfx(this.assets.sfxClear);

    setTimeout(() => {
      const sm = window.settingsManager;
      sm.clearAllData();
      document.getElementById('s-name').value = sm.getName();
      status.textContent = '✅ Данные удалены! Перезапуск...';
      status.style.color = '#8affb0';
      setTimeout(() => location.reload(), 1200);
    }, 400);
  },

  back() {
    if (this.isClosing) return;
    this.isClosing = true;
    this.playSfx(this.assets.sfxBack);

    const container = document.getElementById('settings-container');
    container.classList.remove('show');
    container.classList.add('hide');
    
    this.fadeMusic();

    setTimeout(() => {
      if (window.MenuBlock && typeof window.MenuBlock.init === 'function') {
        window.MenuBlock.init();
      }
    }, 700);
  },

  playSfx(url) {
    try {
      const audio = new Audio(url);
      audio.volume = 0.8;
      audio.play().catch(() => {});
    } catch(e) {}
  },

  playMusic() {
    try {
      this.audio = new Audio(this.assets.trackSettings);
      this.audio.loop = true;
      this.audio.volume = 0.7;
      this.audio.play().catch(() => {});
    } catch(e) {
      console.warn('Музыка не загрузилась');
    }
  },

  fadeMusic() {
    if (!this.audio) return;
    let vol = this.audio.volume;
    const interval = setInterval(() => {
      if (vol > 0.05) {
        vol -= 0.05;
        this.audio.volume = vol;
      } else {
        this.audio.volume = 0;
        this.audio.pause();
        clearInterval(interval);
      }
    }, 30);
  }
};