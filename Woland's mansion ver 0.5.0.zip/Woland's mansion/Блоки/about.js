/* =========================================================
   1. КЛАСС МИНИ-ИГРЫ "ОСОБНЯК ГАЛКИНА"
   ========================================================= */
class GalkinMansionGame {
    constructor() {
        this.canvas = null;
        this.ctx = null;

        this.WIDTH = 360;
        this.HEIGHT = 270;
        this.FPS = 24;
        this.frameInterval = 1000 / this.FPS;
        this.lastFrameTime = 0;

        this.state = 'LOGO';
        this.level = 1;
        this.maxLevels = 25;
        this.score = 0;
        this.lives = 3;
        this.menuSelect = 0;
        this.levelTimeLeft = 30;
        this.lastSecondTick = 0;
        this.totalCandlesCollected = 0;
        this.totalCandlesAvailable = 0;
        this.totalLevelsCompleted = 0;
        this.totalTimePlayed = 0;
        this.gameStartTime = 0;
        this.bonusScore = 0;
        this.candleScore = 0;
        this.levelScore = 0;
        this.timeScore = 0;
        this.mushroomPenalty = 0;
        this.collisionPenalty = 0;

        this.audioCtx = null;
        this.ghostGainNode = null;
        this.ghostOsc = null;
        this.ghostLfo = null;

        this.thereminOsc = null;
        this.thereminLfo = null;
        this.thereminGain = null;
        this.thereminTimer = null;

        this.gameOverAudio = null;
        this.rankingAudio = null;
        this.currentRankingAudio = null;

        this.keys = { up: false, down: false, left: false, right: false, ok: false, back: false };
        this.prevKeys = { ...this.keys };

        this.player = {
            x: 28, y: 38,
            w: 16, h: 20,
            dir: 0,
            frame: 0,
            animTimer: 0,
            baseSpeed: 2.2,
            debuffType: null,
            debuffTimer: 0
        };

        this.candles = [];
        this.mushrooms = [];
        this.cobwebs = [];
        this.ghosts = [];
        this.walls = [];

        this.records = [];
        this.tickCount = 0;
        this.animFrameId = null;

        this.resultsData = null;
        this.resultsLines = [];
        this.resultsAnimIndex = 0;
        this.resultsAnimTimer = 0;
        this.resultsAnimDone = false;
        this.isResultsAnimating = false;
        this.canSkipResults = false;
        this.currentLineAnimDone = true;

        this.boundKeyDown = null;
        this.boundKeyUp = null;
        this.boundUnlockAudio = null;
        this.boundModalClick = null;
    }

    init() {
        this.canvas = document.getElementById('snes-screen');
        if (!this.canvas) {
            console.error('Элемент canvas с id "snes-screen" не найден!');
            return;
        }

        this.ctx = this.canvas.getContext('2d');
        if (this.ctx) {
            this.ctx.imageSmoothingEnabled = false;
        }

        try {
            this.records = JSON.parse(localStorage.getItem('galkin_mansion_records')) || [];
        } catch (e) {
            this.records = [];
        }

        this.setupAudio();
        this.setupControls();
        this.startLogoSequence();
        this.animFrameId = requestAnimationFrame((t) => this.loop(t));
    }

    stop() {
        if (this.animFrameId) {
            cancelAnimationFrame(this.animFrameId);
            this.animFrameId = null;
        }

        this.stopThereminMusic();
        this.stopGhostSound();
        this.stopGameOverAudio();
        this.stopRankingAudio();
        this.removeControls();

        if (this.audioCtx && this.audioCtx.state !== 'closed') {
            try { this.audioCtx.suspend(); } catch(e) {}
        }
    }

    setupAudio() {
        this.boundUnlockAudio = () => {
            if (!this.audioCtx) {
                const AudioCtx = window.AudioContext || window.webkitAudioContext;
                if (AudioCtx) {
                    this.audioCtx = new AudioCtx();
                }
            }
            if (this.audioCtx && this.audioCtx.state === 'suspended') {
                this.audioCtx.resume();
            }
            window.removeEventListener('click', this.boundUnlockAudio);
            window.removeEventListener('touchstart', this.boundUnlockAudio);
            window.removeEventListener('keydown', this.boundUnlockAudio);
        };

        window.addEventListener('click', this.boundUnlockAudio);
        window.addEventListener('touchstart', this.boundUnlockAudio);
        window.addEventListener('keydown', this.boundUnlockAudio);
    }

    startThereminMusic() {
        if (!this.audioCtx) return;
        if (this.thereminOsc) return;
        if (this.audioCtx.state === 'suspended') {
            this.audioCtx.resume();
        }

        const now = this.audioCtx.currentTime;
        this.thereminOsc = this.audioCtx.createOscillator();
        this.thereminLfo = this.audioCtx.createOscillator();
        const lfoGain = this.audioCtx.createGain();
        this.thereminGain = this.audioCtx.createGain();

        this.thereminOsc.type = 'sine';
        this.thereminOsc.frequency.setValueAtTime(300, now);

        this.thereminLfo.type = 'sine';
        this.thereminLfo.frequency.setValueAtTime(5.5, now);
        lfoGain.gain.setValueAtTime(12, now);

        this.thereminLfo.connect(lfoGain);
        lfoGain.connect(this.thereminOsc.frequency);

        this.thereminGain.gain.setValueAtTime(0.08, now);

        this.thereminOsc.connect(this.thereminGain);
        this.thereminGain.connect(this.audioCtx.destination);

        this.thereminOsc.start();
        this.thereminLfo.start();

        const notes = [220, 233, 261, 277, 311, 329, 349, 415, 440, 311, 233, 196];
        let noteIdx = 0;
        this.thereminTimer = setInterval(() => {
            if (!this.thereminOsc || !this.audioCtx) return;
            noteIdx = (noteIdx + 1) % notes.length;
            const targetFreq = notes[noteIdx] + (Math.random() * 8 - 4);
            this.thereminOsc.frequency.exponentialRampToValueAtTime(targetFreq, this.audioCtx.currentTime + 0.4);
        }, 450);
    }

    stopThereminMusic() {
        if (this.thereminTimer) {
            clearInterval(this.thereminTimer);
            this.thereminTimer = null;
        }
        if (this.thereminGain && this.audioCtx) {
            this.thereminGain.gain.linearRampToValueAtTime(0.001, this.audioCtx.currentTime + 0.3);
            setTimeout(() => {
                if (this.thereminOsc) {
                    try {
                        this.thereminOsc.stop();
                        this.thereminOsc.disconnect();
                    } catch (e) {}
                    this.thereminOsc = null;
                }
                if (this.thereminLfo) {
                    try {
                        this.thereminLfo.stop();
                        this.thereminLfo.disconnect();
                    } catch (e) {}
                    this.thereminLfo = null;
                }
            }, 350);
        }
    }

    initGhostSound() {
        if (!this.audioCtx || this.ghostOsc) return;

        this.ghostOsc = this.audioCtx.createOscillator();
        this.ghostLfo = this.audioCtx.createOscillator();
        const lfoGain = this.audioCtx.createGain();
        this.ghostGainNode = this.audioCtx.createGain();

        this.ghostOsc.type = 'sawtooth';
        this.ghostOsc.frequency.setValueAtTime(100, this.audioCtx.currentTime);

        this.ghostLfo.type = 'sine';
        this.ghostLfo.frequency.setValueAtTime(0.7, this.audioCtx.currentTime);
        lfoGain.gain.setValueAtTime(50, this.audioCtx.currentTime);

        this.ghostLfo.connect(lfoGain);
        lfoGain.connect(this.ghostOsc.frequency);

        this.ghostGainNode.gain.setValueAtTime(0, this.audioCtx.currentTime);
        this.ghostOsc.connect(this.ghostGainNode);
        this.ghostGainNode.connect(this.audioCtx.destination);

        this.ghostOsc.start();
        this.ghostLfo.start();
    }

    stopGhostSound() {
        if (this.ghostGainNode && this.audioCtx) {
            this.ghostGainNode.gain.linearRampToValueAtTime(0, this.audioCtx.currentTime + 0.1);
        }
        setTimeout(() => {
            if (this.ghostOsc) {
                try { this.ghostOsc.stop(); this.ghostOsc.disconnect(); } catch(e){}
                this.ghostOsc = null;
            }
            if (this.ghostLfo) {
                try { this.ghostLfo.stop(); this.ghostLfo.disconnect(); } catch(e){}
                this.ghostLfo = null;
            }
        }, 150);
    }

    setGhostVolume(vol, duration = 0.1) {
        if (!this.ghostGainNode || !this.audioCtx) return;
        const now = this.audioCtx.currentTime;
        this.ghostGainNode.gain.cancelScheduledValues(now);
        this.ghostGainNode.gain.linearRampToValueAtTime(vol, now + duration);
    }

    playSound(type) {
        if (!this.audioCtx) return;
        if (this.audioCtx.state === 'suspended') {
            this.audioCtx.resume();
        }

        const now = this.audioCtx.currentTime;

        if (type === 'step') {
            const osc = this.audioCtx.createOscillator();
            const gain = this.audioCtx.createGain();
            osc.type = 'triangle';
            osc.frequency.setValueAtTime(80 + Math.random() * 25, now);
            gain.gain.setValueAtTime(0.05, now);
            gain.gain.exponentialRampToValueAtTime(0.001, now + 0.04);
            osc.connect(gain);
            gain.connect(this.audioCtx.destination);
            osc.start(now); osc.stop(now + 0.04);
            return;
        }

        this.setGhostVolume(0.01, 0.05);
        setTimeout(() => {
            if (this.state === 'GAME') this.setGhostVolume(0.05, 0.2);
        }, 300);

        const osc = this.audioCtx.createOscillator();
        const gain = this.audioCtx.createGain();
        osc.connect(gain);
        gain.connect(this.audioCtx.destination);

        if (type === 'nintendo') {
            osc.type = 'square';
            osc.frequency.setValueAtTime(987.77, now);
            osc.frequency.setValueAtTime(1318.51, now + 0.08);
            gain.gain.setValueAtTime(0.18, now);
            gain.gain.exponentialRampToValueAtTime(0.001, now + 0.5);
            osc.start(now); osc.stop(now + 0.5);
        } else if (type === 'candle') {
            osc.type = 'square';
            osc.frequency.setValueAtTime(880, now);
            osc.frequency.setValueAtTime(1320, now + 0.05);
            gain.gain.setValueAtTime(0.12, now);
            gain.gain.exponentialRampToValueAtTime(0.01, now + 0.18);
            osc.start(now); osc.stop(now + 0.18);
        } else if (type === 'mushroom') {
            osc.type = 'sawtooth';
            osc.frequency.setValueAtTime(320, now);
            osc.frequency.linearRampToValueAtTime(90, now + 0.3);
            gain.gain.setValueAtTime(0.2, now);
            gain.gain.exponentialRampToValueAtTime(0.01, now + 0.3);
            osc.start(now); osc.stop(now + 0.3);
        } else if (type === 'select') {
            osc.type = 'triangle';
            osc.frequency.setValueAtTime(240, now);
            gain.gain.setValueAtTime(0.1, now);
            gain.gain.exponentialRampToValueAtTime(0.01, now + 0.08);
            osc.start(now); osc.stop(now + 0.08);
        } else if (type === 'hit') {
            osc.type = 'sawtooth';
            osc.frequency.setValueAtTime(200, now);
            osc.frequency.exponentialRampToValueAtTime(35, now + 0.35);
            gain.gain.setValueAtTime(0.25, now);
            gain.gain.exponentialRampToValueAtTime(0.01, now + 0.35);
            osc.start(now); osc.stop(now + 0.35);
        } else if (type === 'gameover') {
            const notes = [220, 207, 196, 185, 174, 164, 155, 130];
            notes.forEach((freq, idx) => {
                const gOsc = this.audioCtx.createOscillator();
                const gGain = this.audioCtx.createGain();
                gOsc.type = 'sawtooth';
                gOsc.frequency.setValueAtTime(freq, now + idx * 0.075);
                gGain.gain.setValueAtTime(0.15, now + idx * 0.075);
                gGain.gain.exponentialRampToValueAtTime(0.001, now + (idx + 1) * 0.075);
                gOsc.connect(gGain);
                gOsc.connect(this.audioCtx.destination);
                gOsc.start(now + idx * 0.075);
                gOsc.stop(now + (idx + 1) * 0.075);
            });
        }
    }

    setupControls() {
        const bindBtn = (id, key) => {
            const el = document.getElementById(id);
            if (!el) return;
            const start = (e) => { e.preventDefault(); this.keys[key] = true; };
            const end = (e) => { e.preventDefault(); this.keys[key] = false; };
            el.addEventListener('mousedown', start); el.addEventListener('mouseup', end);
            el.addEventListener('touchstart', start, { passive: false }); 
            el.addEventListener('touchend', end, { passive: false });
        };

        bindBtn('btn-u', 'up'); bindBtn('btn-d', 'down');
        bindBtn('btn-l', 'left'); bindBtn('btn-r', 'right');
        bindBtn('btn-ok', 'ok'); bindBtn('btn-back', 'back');

        this.boundKeyDown = (e) => {
            if (e.key === 'ArrowUp' || e.key === 'w' || e.key === 'W') this.keys.up = true;
            if (e.key === 'ArrowDown' || e.key === 's' || e.key === 'S') this.keys.down = true;
            if (e.key === 'ArrowLeft' || e.key === 'a' || e.key === 'A') this.keys.left = true;
            if (e.key === 'ArrowRight' || e.key === 'd' || e.key === 'D') this.keys.right = true;
            if (e.key === 'Enter' || e.key === ' ') this.keys.ok = true;
            if (e.key === 'Escape' || e.key === 'Backspace') this.keys.back = true;
        };

        this.boundKeyUp = (e) => {
            if (e.key === 'ArrowUp' || e.key === 'w' || e.key === 'W') this.keys.up = false;
            if (e.key === 'ArrowDown' || e.key === 's' || e.key === 'S') this.keys.down = false;
            if (e.key === 'ArrowLeft' || e.key === 'a' || e.key === 'A') this.keys.left = false;
            if (e.key === 'ArrowRight' || e.key === 'd' || e.key === 'D') this.keys.right = false;
            if (e.key === 'Enter' || e.key === ' ') this.keys.ok = false;
            if (e.key === 'Escape' || e.key === 'Backspace') this.keys.back = false;
        };

        window.addEventListener('keydown', this.boundKeyDown);
        window.addEventListener('keyup', this.boundKeyUp);

        this.boundModalClick = (e) => {
            if (this.state === 'RESULTS') {
                if (this.isResultsAnimating && this.canSkipResults) {
                    this.skipCurrentLineAnimation();
                } else if (this.resultsAnimDone) {
                    if (this.isPressed('ok') || this.isPressed('back')) {
                        this.stopRankingAudio();
                        this.state = 'MENU';
                        this.startThereminMusic();
                    }
                }
            }
        };
        window.addEventListener('click', this.boundModalClick);
        window.addEventListener('touchstart', this.boundModalClick, { passive: true });
    }

    removeControls() {
        if (this.boundKeyDown) window.removeEventListener('keydown', this.boundKeyDown);
        if (this.boundKeyUp) window.removeEventListener('keyup', this.boundKeyUp);
        if (this.boundUnlockAudio) {
            window.removeEventListener('click', this.boundUnlockAudio);
            window.removeEventListener('touchstart', this.boundUnlockAudio);
            window.removeEventListener('keydown', this.boundUnlockAudio);
        }
        if (this.boundModalClick) {
            window.removeEventListener('click', this.boundModalClick);
            window.removeEventListener('touchstart', this.boundModalClick);
        }
    }

    isPressed(key) {
        return this.keys[key] && !this.prevKeys[key];
    }

    startLogoSequence() {
        this.state = 'LOGO';
        setTimeout(() => this.playSound('nintendo'), 300);
        setTimeout(() => { 
            if (this.state === 'LOGO') {
                this.state = 'MENU'; 
                this.startThereminMusic();
            }
        }, 2200);
    }

    initLevel(lvl) {
        this.level = lvl;
        this.levelTimeLeft = 30;
        this.lastSecondTick = 0;
        this.candles = [];
        this.mushrooms = [];
        this.cobwebs = [];
        this.ghosts = [];
        this.walls = [];
        this.player.debuffTimer = 0;
        this.player.debuffType = null;

        const TILE = 24;

        for (let x = 0; x < this.WIDTH; x += TILE) {
            this.walls.push({ x, y: 20, w: TILE, h: TILE });
            this.walls.push({ x, y: this.HEIGHT - TILE, w: TILE, h: TILE });
        }
        for (let y = 20; y < this.HEIGHT; y += TILE) {
            this.walls.push({ x: 0, y, w: TILE, h: TILE });
            this.walls.push({ x: this.WIDTH - TILE, y, w: TILE, h: TILE });
        }

        const type = (lvl - 1) % 4;
        if (type === 0) {
            this.walls.push({ x: TILE * 3, y: TILE * 3, w: TILE * 2, h: TILE * 2 });
            this.walls.push({ x: TILE * 10, y: TILE * 3, w: TILE * 2, h: TILE * 2 });
            this.walls.push({ x: TILE * 6, y: TILE * 7, w: TILE * 3, h: TILE * 2 });
        } else if (type === 1) {
            for (let y = TILE * 2; y <= TILE * 8; y += TILE * 3) {
                this.walls.push({ x: TILE * 3, y, w: TILE * 4, h: TILE });
                this.walls.push({ x: TILE * 8, y: y + TILE, w: TILE * 4, h: TILE });
            }
        } else if (type === 2) {
            this.walls.push({ x: TILE * 4, y: TILE * 2, w: TILE, h: TILE * 5 });
            this.walls.push({ x: TILE * 9, y: TILE * 4, w: TILE, h: TILE * 5 });
            this.walls.push({ x: TILE * 6, y: TILE * 3, w: TILE * 3, h: TILE });
        } else if (type === 3) {
            this.walls.push({ x: TILE * 5, y: TILE * 3, w: TILE * 5, h: TILE * 4 });
            this.walls.push({ x: TILE * 2, y: TILE * 6, w: TILE * 2, h: TILE });
            this.walls.push({ x: TILE * 11, y: TILE * 4, w: TILE * 2, h: TILE });
        }

        const cSlots = [
            { x: 30, y: 55 }, { x: 310, y: 55 }, { x: 30, y: 220 },
            { x: 310, y: 220 }, { x: 170, y: 55 }, { x: 170, y: 220 },
            { x: 90, y: 140 }, { x: 250, y: 140 }
        ];
        const candleCount = Math.min(4 + Math.floor(lvl * 0.25), cSlots.length);
        for (let i = 0; i < candleCount; i++) {
            this.candles.push({ x: cSlots[i].x, y: cSlots[i].y, w: 10, h: 14 });
        }
        this.totalCandlesAvailable += candleCount;

        const mTypes = ['shrink', 'invert'];
        const mCount = 1 + Math.floor(lvl / 6);
        for (let i = 0; i < mCount; i++) {
            this.mushrooms.push({
                x: 80 + (i * 110) % 200,
                y: 80 + (i * 70) % 120,
                type: mTypes[i % mTypes.length],
                w: 14, h: 14
            });
        }

        const webCount = Math.min(Math.floor(lvl / 2), 5);
        for (let i = 0; i < webCount; i++) {
            this.cobwebs.push({
                x: 60 + (i * 50),
                y: 100 + ((i * 35) % 80),
                w: 20, h: 20
            });
        }

        const gCount = Math.min(1 + Math.floor(lvl / 3), 7);
        const gSpeed = 0.6 + (lvl * 0.07);
        for (let i = 0; i < gCount; i++) {
            this.ghosts.push({
                x: 220 + (i * 15), y: 70 + (i * 25),
                w: 16, h: 18,
                vx: (i % 2 === 0 ? 1 : -1) * gSpeed,
                vy: (i % 2 === 0 ? -1 : 1) * gSpeed,
                eyeX: 0, eyeY: 0
            });
        }

        this.player.x = 28;
        this.player.y = 48;

        this.initGhostSound();
        this.setGhostVolume(0.05);
    }

    loop(timestamp) {
        if (!this.animFrameId) return;

        if (!this.lastFrameTime) this.lastFrameTime = timestamp;
        const delta = timestamp - this.lastFrameTime;

        if (delta >= this.frameInterval) {
            this.lastFrameTime = timestamp - (delta % this.frameInterval);
            this.tickCount++;
            this.update();
            this.render();
            this.prevKeys = { ...this.keys };
        }

        this.animFrameId = requestAnimationFrame((t) => this.loop(t));
    }

    checkCollision(r1, r2) {
        return r1.x < r2.x + r2.w &&
               r1.x + r1.w > r2.x &&
               r1.y < r2.y + r2.h &&
               r1.y + r1.h > r2.y;
    }

    update() {
        if (this.state === 'MENU') {
            this.setGhostVolume(0);
            if (!this.thereminOsc) this.startThereminMusic();

            if (this.isPressed('up') || this.isPressed('down')) {
                this.menuSelect = this.menuSelect === 0 ? 1 : 0;
                this.playSound('select');
            }
            if (this.isPressed('ok')) {
                this.playSound('select');
                if (this.menuSelect === 0) {
                    this.stopThereminMusic();
                    this.score = 0;
                    this.lives = 3;
                    this.totalCandlesCollected = 0;
                    this.totalCandlesAvailable = 0;
                    this.totalLevelsCompleted = 0;
                    this.candleScore = 0;
                    this.levelScore = 0;
                    this.timeScore = 0;
                    this.mushroomPenalty = 0;
                    this.collisionPenalty = 0;
                    this.bonusScore = 0;
                    this.totalTimePlayed = 0;
                    this.gameStartTime = Date.now();
                    this.initLevel(1);
                    this.state = 'GAME';
                } else {
                    this.state = 'RECORDS';
                }
            }
        } else if (this.state === 'RECORDS') {
            if (!this.thereminOsc) this.startThereminMusic();

            if (this.isPressed('ok') || this.isPressed('back')) {
                this.playSound('select');
                this.state = 'MENU';
            }
        } else if (this.state === 'GAME') {
            if (this.isPressed('back')) {
                this.setGhostVolume(0);
                this.state = 'MENU';
                this.startThereminMusic();
                return;
            }

            this.lastSecondTick++;
            if (this.lastSecondTick >= 24) {
                this.lastSecondTick = 0;
                this.levelTimeLeft--;
                this.totalTimePlayed++;
                
                if (this.levelTimeLeft <= 0) {
                    this.calculateFinalResults(false);
                    this.state = 'GAMEOVER_SCREEN';
                    this.playGameOverAudio();
                    this.setGhostVolume(0);
                    return;
                }
            }

            if (this.player.debuffTimer > 0) {
                this.player.debuffTimer--;
                if (this.player.debuffTimer === 0) {
                    this.player.debuffType = null;
                }
            }

            let inWeb = this.cobwebs.some(web => this.checkCollision(this.player, web));
            
            let curSpeed = this.player.baseSpeed;
            if (this.player.debuffType === 'shrink') curSpeed *= 0.55;
            if (inWeb) curSpeed *= 0.5;

            let moveUp = this.keys.up;
            let moveDown = this.keys.down;
            let moveLeft = this.keys.left;
            let moveRight = this.keys.right;

            if (this.player.debuffType === 'invert') {
                let tmpU = moveUp, tmpD = moveDown, tmpL = moveLeft, tmpR = moveRight;
                moveUp = tmpD; moveDown = tmpU; moveLeft = tmpR; moveRight = tmpL;
            }

            let dx = 0, dy = 0;
            if (moveLeft) { dx -= curSpeed; this.player.dir = 2; }
            else if (moveRight) { dx += curSpeed; this.player.dir = 3; }

            if (moveUp) { dy -= curSpeed; this.player.dir = 1; }
            else if (moveDown) { dy += curSpeed; this.player.dir = 0; }

            if (dx !== 0 || dy !== 0) {
                this.player.animTimer++;
                if (this.player.animTimer % 4 === 0) {
                    this.player.frame = (this.player.frame + 1) % 4;
                    this.playSound('step');
                }

                let pBoxX = { x: this.player.x + dx, y: this.player.y, w: this.player.w, h: this.player.h };
                if (!this.walls.some(w => this.checkCollision(pBoxX, w))) {
                    this.player.x += dx;
                }

                let pBoxY = { x: this.player.x, y: this.player.y + dy, w: this.player.w, h: this.player.h };
                if (!this.walls.some(w => this.checkCollision(pBoxY, w))) {
                    this.player.y += dy;
                }
            } else {
                this.player.frame = 0;
            }

            for (let i = this.mushrooms.length - 1; i >= 0; i--) {
                const m = this.mushrooms[i];
                if (this.checkCollision(this.player, m)) {
                    this.player.debuffType = m.type;
                    this.player.debuffTimer = 120;
                    this.mushrooms.splice(i, 1);
                    this.playSound('mushroom');
                }
            }

            for (let i = this.candles.length - 1; i >= 0; i--) {
                const c = this.candles[i];
                if (this.checkCollision(this.player, c)) {
                    this.candles.splice(i, 1);
                    this.score += 50;
                    this.candleScore += 50;
                    this.totalCandlesCollected++;
                    this.playSound('candle');
                }
            }

            if (this.candles.length === 0) {
                this.score += 50;
                this.levelScore += 50;
                this.totalLevelsCompleted++;
                
                const timeBonus = this.levelTimeLeft * 10;
                this.score += timeBonus;
                this.timeScore += timeBonus;

                if (this.level < this.maxLevels) {
                    if (this.level % 5 === 0) {
                        this.score += 200;
                        this.bonusScore += 200;
                    }
                    this.initLevel(this.level + 1);
                } else {
                    if (this.level % 5 === 0) {
                        this.score += 200;
                        this.bonusScore += 200;
                    }
                    this.calculateFinalResults(true);
                    this.state = 'RESULTS';
                    this.playRankingAudio();
                    this.setGhostVolume(0);
                }
            }

            this.ghosts.forEach(g => {
                g.x += g.vx; g.y += g.vy;

                if (g.x < 24 || g.x > this.WIDTH - 24 - g.w) g.vx *= -1;
                if (g.y < 40 || g.y > this.HEIGHT - 24 - g.h) g.vy *= -1;

                g.eyeX = this.player.x > g.x ? 1 : -1;
                g.eyeY = this.player.y > g.y ? 1 : -1;

                if (this.checkCollision(this.player, g)) {
                    this.lives--;
                    this.score -= 40;
                    this.collisionPenalty -= 40;
                    this.playSound('hit');
                    if (this.lives <= 0) {
                        this.calculateFinalResults(false);
                        this.setGhostVolume(0);
                        this.state = 'GAMEOVER_SCREEN';
                        this.playGameOverAudio();
                    } else {
                        this.player.x = 28;
                        this.player.y = 48;
                    }
                }
            });
        } else if (this.state === 'GAMEOVER_SCREEN') {
            this.setGhostVolume(0);
            if (this.gameOverAudio && this.gameOverAudio.ended) {
                this.showResults();
            }
        } else if (this.state === 'RESULTS') {
            if (this.isResultsAnimating && this.canSkipResults) {
                if (this.isPressed('ok') || this.isPressed('back')) {
                    this.skipCurrentLineAnimation();
                }
            }
            if (this.resultsAnimDone) {
                if (this.isPressed('ok') || this.isPressed('back')) {
                    this.stopRankingAudio();
                    this.state = 'MENU';
                    this.startThereminMusic();
                }
            }
        }
    }

    calculateFinalResults(completed) {
        const totalGameTime = Math.floor((Date.now() - this.gameStartTime) / 1000);
        
        const finalScore = this.score;
        
        this.resultsData = {
            candlesCollected: this.totalCandlesCollected,
            candlesAvailable: this.totalCandlesAvailable,
            levelsCompleted: this.totalLevelsCompleted,
            totalLevels: 25,
            timePlayed: totalGameTime,
            timeAvailable: 25 * 30,
            candleScore: this.candleScore,
            levelScore: this.levelScore,
            bonusScore: this.bonusScore,
            timeScore: this.timeScore,
            mushroomPenalty: this.mushroomPenalty,
            collisionPenalty: this.collisionPenalty,
            finalScore: finalScore,
            rank: this.calculateRank(finalScore, completed)
        };

        this.saveRecord(finalScore, this.resultsData.rank);
    }

    calculateRank(score, completed) {
        const maxCandles = this.totalCandlesAvailable;
        const maxLevels = 25;
        const maxTime = 25 * 30;
        
        const maxScore = maxCandles * 50 + maxLevels * 50 + maxTime * 10 + Math.floor(maxLevels / 5) * 200;
        
        const percentage = maxScore > 0 ? (score / maxScore) * 100 : 0;
        
        if (percentage >= 85) return 'A';
        if (percentage >= 70) return 'B';
        if (percentage >= 55) return 'C';
        if (percentage >= 40) return 'D';
        if (percentage >= 25) return 'E';
        if (percentage >= 12) return 'F';
        if (percentage >= 5) return 'G';
        return 'H';
    }

    playGameOverAudio() {
        this.stopRankingAudio();
        if (this.gameOverAudio) {
            this.gameOverAudio.pause();
            this.gameOverAudio.currentTime = 0;
        }
        this.gameOverAudio = new Audio('https://github.com/Daniil160111/Woland-s-mansion/raw/refs/heads/main/93.%20Game%20Over.mp3');
        this.gameOverAudio.loop = false;
        this.gameOverAudio.volume = 0.5;
        this.gameOverAudio.play().catch(() => {
            setTimeout(() => this.showResults(), 3000);
        });
    }

    playRankingAudio() {
        this.stopGameOverAudio();
        const rank = this.resultsData ? this.resultsData.rank : 'H';
        
        let audioUrl;
        if (rank === 'A') {
            audioUrl = 'https://github.com/Daniil160111/Woland-s-mansion/raw/refs/heads/main/90.%20Ranking%20A.mp3';
        } else if (rank === 'H') {
            audioUrl = 'https://github.com/Daniil160111/Woland-s-mansion/raw/refs/heads/main/92.%20Ranking%20H.mp3';
        } else {
            audioUrl = 'https://github.com/Daniil160111/Woland-s-mansion/raw/refs/heads/main/91.%20Ranking%20B-G.mp3';
        }
        
        this.rankingAudio = new Audio(audioUrl);
        this.rankingAudio.loop = false;
        this.rankingAudio.volume = 0.5;
        this.rankingAudio.play().catch(() => {});
    }

    stopGameOverAudio() {
        if (this.gameOverAudio) {
            this.gameOverAudio.pause();
            this.gameOverAudio = null;
        }
    }

    stopRankingAudio() {
        if (this.rankingAudio) {
            this.rankingAudio.pause();
            this.rankingAudio = null;
        }
    }

    showResults() {
        this.stopGameOverAudio();
        this.state = 'RESULTS';
        this.playRankingAudio();
        
        this.resultsLines = [
            { label: 'Ваш итог!', type: 'header', value: '' },
            { label: 'Собрано свечей', type: 'stat', value: this.resultsData.candlesCollected, max: this.resultsData.candlesAvailable },
            { label: 'Пройдено уровней', type: 'stat', value: this.resultsData.levelsCompleted, max: this.resultsData.totalLevels },
            { label: 'Время игры', type: 'stat', value: this.resultsData.timePlayed, max: this.resultsData.timeAvailable },
            { label: '------------', type: 'divider', value: '' },
            { label: 'Очки за свечки', type: 'score', value: this.resultsData.candleScore },
            { label: 'Очки за уровни', type: 'score', value: this.resultsData.levelScore },
            { label: 'Бонусовые очки', type: 'score', value: this.resultsData.bonusScore },
            { label: 'Очки за время', type: 'score', value: this.resultsData.timeScore },
            { label: 'Очки за грибы', type: 'score', value: this.resultsData.mushroomPenalty },
            { label: 'Очки за столкновения', type: 'score', value: this.resultsData.collisionPenalty },
            { label: '------------', type: 'divider', value: '' },
            { label: 'Итог:', type: 'header', value: '' },
            { label: 'Ваш результат - ' + this.resultsData.rank, type: 'rank', value: '' },
            { label: 'Счёт: ' + this.resultsData.finalScore, type: 'final', value: '' }
        ];
        
        this.resultsAnimIndex = 0;
        this.resultsAnimTimer = 0;
        this.resultsAnimDone = false;
        this.isResultsAnimating = true;
        this.canSkipResults = true;
        this.currentLineAnimDone = true;
    }

    skipCurrentLineAnimation() {
        if (this.resultsAnimIndex < this.resultsLines.length) {
            this.resultsAnimIndex++;
            this.resultsAnimTimer = 0;
            this.currentLineAnimDone = true;
            
            if (this.resultsAnimIndex >= this.resultsLines.length) {
                this.resultsAnimDone = true;
                this.isResultsAnimating = false;
                this.canSkipResults = false;
            }
        }
    }

    saveRecord(valScore, rank) {
        const durationSec = Math.floor((Date.now() - this.gameStartTime) / 1000);
        const now = new Date();
        const dateStr = `${String(now.getDate()).padStart(2, '0')}.${String(now.getMonth() + 1).padStart(2, '0')}.${now.getFullYear()} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;

        this.records.unshift({
            score: valScore,
            rank: rank,
            level: this.totalLevelsCompleted,
            candles: this.totalCandlesCollected,
            candlesTotal: this.totalCandlesAvailable,
            time: durationSec,
            date: dateStr
        });

        this.records = this.records.slice(0, 10);
        try {
            localStorage.setItem('galkin_mansion_records', JSON.stringify(this.records));
        } catch (e) {}
    }

    drawGalkin(x, y, dir, frame, debuffType) {
        if (!this.ctx) return;
        this.ctx.save();
        this.ctx.translate(x, y);

        if (debuffType === 'shrink') this.ctx.scale(0.7, 0.7);

        this.ctx.fillStyle = '#ffffff';
        this.ctx.fillRect(6, -6, 4, 3);
        this.ctx.fillRect(8, -4, 3, 2);

        this.ctx.fillStyle = '#ffdbac';
        this.ctx.fillRect(3, 0, 10, 8);

        this.ctx.fillStyle = '#00c8c8';
        if (dir === 0) {
            this.ctx.fillRect(2, 3, 4, 4);
            this.ctx.fillRect(10, 3, 4, 4);
            this.ctx.fillStyle = '#ffffff';
            this.ctx.fillRect(7, 7, 2, 2);
        } else if (dir === 1) {
            this.ctx.fillStyle = '#ffffff';
            this.ctx.fillRect(3, 0, 10, 6);
        } else if (dir === 2) {
            this.ctx.fillRect(1, 3, 4, 4);
            this.ctx.fillStyle = '#ffffff';
            this.ctx.fillRect(3, 7, 2, 2);
        } else if (dir === 3) {
            this.ctx.fillRect(11, 3, 4, 4);
            this.ctx.fillStyle = '#ffffff';
            this.ctx.fillRect(11, 7, 2, 2);
        }

        this.ctx.fillStyle = '#e01020';
        this.ctx.fillRect(5, 8, 6, 3);
        this.ctx.fillStyle = '#ffffff';
        this.ctx.fillRect(3, 11, 10, 5);

        this.ctx.fillStyle = '#442200';
        let step = (frame % 2 === 0) ? 0 : 3;
        this.ctx.fillRect(3, 16 + step, 4, 3);
        this.ctx.fillRect(9, 16 + (3 - step), 4, 3);

        if (debuffType === 'invert') {
            this.ctx.strokeStyle = '#a000ff';
            this.ctx.lineWidth = 1;
            this.ctx.strokeRect(-2, -6, 20, 26);
        }

        this.ctx.restore();
    }

    drawGhost(g, idx) {
        if (!this.ctx) return;
        this.ctx.save();
        
        const floatOffset = Math.sin(this.tickCount * 0.2 + idx) * 3;
        const gx = g.x;
        const gy = g.y + floatOffset;

        this.ctx.fillStyle = 'rgba(220, 230, 255, 0.88)';

        this.ctx.beginPath();
        this.ctx.arc(gx + 8, gy + 7, 7, Math.PI, 0, false);
        this.ctx.fillRect(gx + 1, gy + 7, 14, 6);
        this.ctx.fill();

        this.ctx.beginPath();
        this.ctx.moveTo(gx + 1, gy + 13);
        
        const wave = Math.sin(this.tickCount * 0.35 + idx) * 2;
        
        this.ctx.lineTo(gx + 4, gy + 16 + wave);
        this.ctx.lineTo(gx + 7, gy + 13);
        this.ctx.lineTo(gx + 10, gy + 16 - wave);
        this.ctx.lineTo(gx + 13, gy + 13);
        this.ctx.lineTo(gx + 15, gy + 16 + wave);
        this.ctx.lineTo(gx + 15, gy + 13);
        this.ctx.closePath();
        this.ctx.fill();

        this.ctx.fillStyle = '#100030';
        this.ctx.fillRect(gx + 3, gy + 5, 3, 4);
        this.ctx.fillRect(gx + 10, gy + 5, 3, 4);

        this.ctx.fillStyle = '#ff0033';
        this.ctx.fillRect(gx + 4 + g.eyeX, gy + 6 + g.eyeY, 2, 2);
        this.ctx.fillRect(gx + 11 + g.eyeX, gy + 6 + g.eyeY, 2, 2);

        this.ctx.restore();
    }

    renderResults() {
        if (!this.ctx || !this.resultsData) return;
        
        this.ctx.fillStyle = '#0f0a12';
        this.ctx.fillRect(0, 0, this.WIDTH, this.HEIGHT);
        
        let yPos = 15;
        const lineHeight = 18;
        
        this.resultsLines.forEach((line, index) => {
            if (index > this.resultsAnimIndex) return;
            
            let displayValue = line.value;
            
            if (index === this.resultsAnimIndex && !this.currentLineAnimDone) {
                if (line.type === 'stat') {
                    displayValue = Math.floor(Math.random() * (line.max + 1));
                } else if (line.type === 'score') {
                    const range = Math.max(Math.abs(line.value) * 2, 100);
                    displayValue = Math.floor(Math.random() * range - range / 2);
                }
            }
            
            let text = line.label;
            if (line.type === 'stat') {
                text += ` [${displayValue}] / ${line.max}`;
            } else if (line.type === 'score') {
                text += `: ${displayValue}`;
            } else if (line.type === 'rank') {
                text = line.label;
            } else if (line.type === 'final') {
                text = line.label;
            }
            
            if (line.type === 'header') {
                this.ctx.fillStyle = '#ffaa55';
                this.ctx.font = 'bold 13px monospace';
            } else if (line.type === 'rank') {
                this.ctx.fillStyle = '#ffff00';
                this.ctx.font = 'bold 14px monospace';
            } else if (line.type === 'final') {
                this.ctx.fillStyle = '#00ff66';
                this.ctx.font = 'bold 13px monospace';
            } else if (line.type === 'divider') {
                this.ctx.fillStyle = '#888888';
                this.ctx.font = '10px monospace';
            } else if (line.type === 'score' && typeof line.value === 'number' && line.value < 0) {
                this.ctx.fillStyle = '#ff4444';
                this.ctx.font = '10px monospace';
            } else {
                this.ctx.fillStyle = '#ffffff';
                this.ctx.font = '10px monospace';
            }
            
            this.ctx.fillText(text, 20, yPos);
            yPos += lineHeight;
        });
        
        if (this.resultsAnimDone) {
            this.ctx.fillStyle = '#888888';
            this.ctx.font = '8px monospace';
            this.ctx.fillText('ОК / НАЖМИТЕ — ПРОДОЛЖИТЬ', 105, 262);
        }
    }

    render() {
        if (!this.ctx) return;

        this.ctx.fillStyle = '#0f0a12';
        this.ctx.fillRect(0, 0, this.WIDTH, this.HEIGHT);

        if (this.state === 'LOGO') {
            this.ctx.strokeStyle = '#e60012';
            this.ctx.lineWidth = 4;
            this.ctx.beginPath();
            if (typeof this.ctx.roundRect === 'function') {
                this.ctx.roundRect(50, 85, 260, 65, 32);
            } else {
                this.ctx.rect(50, 85, 260, 65);
            }
            this.ctx.stroke();

            this.ctx.fillStyle = '#e60012';
            this.ctx.font = 'bold 36px "Arial Black", sans-serif';
            this.ctx.fillText('Nintendo', 72, 131);

            this.ctx.font = 'bold 10px sans-serif';
            this.ctx.fillText('®', 285, 106);

            this.ctx.fillStyle = '#ffffff';
            this.ctx.font = '12px sans-serif';
            this.ctx.fillText('x', 176, 172);
            this.ctx.font = 'bold 14px sans-serif';
            this.ctx.fillText('HTML gaming', 133, 192);
        } 
        else if (this.state === 'MENU') {
            this.ctx.fillStyle = '#d02030';
            this.ctx.font = 'bold 15px monospace';
            this.ctx.fillText('ОСОБНЯК ГАЛКИНА', 110, 55);
            this.ctx.fillStyle = '#aaaaaa';
            this.ctx.font = '11px monospace';
            this.ctx.fillText('25 УРОВНЕЙ УЖАСА', 115, 75);

            this.drawGalkin(170, 100, 0, 0, null);

            this.ctx.font = '12px monospace';
            this.ctx.fillStyle = this.menuSelect === 0 ? '#ffff00' : '#777777';
            this.ctx.fillText((this.menuSelect === 0 ? '> ' : '  ') + 'ИГРАТЬ', 125, 160);
            
            this.ctx.fillStyle = this.menuSelect === 1 ? '#ffff00' : '#777777';
            this.ctx.fillText((this.menuSelect === 1 ? '> ' : '  ') + 'РЕКОРДЫ', 125, 185);
        } 
        else if (this.state === 'RECORDS') {
            this.ctx.fillStyle = '#ffff00';
            this.ctx.font = '11px monospace';
            this.ctx.fillText('10 ПОСЛЕДНИХ РЕЗУЛЬТАТОВ:', 90, 22);

            if (this.records.length === 0) {
                this.ctx.fillStyle = '#888888';
                this.ctx.font = '10px monospace';
                this.ctx.fillText('НЕТ РЕКОРДОВ', 135, 120);
            } else {
                this.ctx.font = '8px monospace';
                this.records.forEach((rec, idx) => {
                    this.ctx.fillStyle = '#ffffff';
                    const y = 38 + idx * 19;
                    const dateText = rec.date || '--.--.-- --:--';
                    const timeText = rec.time !== undefined ? `${rec.time}s` : '--';
                    const rankText = rec.rank ? `[${rec.rank}]` : '';
                    const candlesText = rec.candles !== undefined ? `СВ:${rec.candles}/${rec.candlesTotal}` : '';
                    this.ctx.fillText(`${idx + 1}.${rankText}${rec.score}оч|УР:${rec.level}|${timeText}|${candlesText}|${dateText}`, 5, y);
                });
            }

            this.ctx.fillStyle = '#888888';
            this.ctx.font = '9px monospace';
            this.ctx.fillText('ОК / НАЗАД — МЕНЮ', 115, 262);
        } 
        else if (this.state === 'GAME') {
            this.ctx.fillStyle = '#1c1218';
            this.ctx.fillRect(0, 0, this.WIDTH, 20);
            this.ctx.fillStyle = '#ffaa00';
            this.ctx.font = '9px monospace';
            this.ctx.fillText(`УР:${this.level}/25`, 6, 13);
            this.ctx.fillText(`ВРЕМЯ:${this.levelTimeLeft}`, 80, 13);
            this.ctx.fillText(`ОЧКИ:${this.score}`, 170, 13);
            this.ctx.fillText(`ЖИЗНИ:${this.lives}`, 250, 13);

            if (this.player.debuffType) {
                this.ctx.fillStyle = this.player.debuffType === 'shrink' ? '#ff3300' : '#b000ff';
                this.ctx.fillText(`ЭФФЕКТ: ${Math.ceil(this.player.debuffTimer / 24)}s`, 300, 13);
            }

            this.walls.forEach(w => {
                this.ctx.fillStyle = '#4a2c20';
                this.ctx.fillRect(w.x, w.y, w.w, w.h);
                this.ctx.fillStyle = '#2d1910';
                this.ctx.fillRect(w.x + 2, w.y + 2, w.w - 4, w.h - 4);
                this.ctx.fillStyle = '#6e4230';
                this.ctx.fillRect(w.x + 2, w.y + 2, w.w - 4, 2);
            });

            this.cobwebs.forEach(web => {
                this.ctx.strokeStyle = 'rgba(255,255,255,0.35)';
                this.ctx.lineWidth = 1;
                this.ctx.beginPath();
                this.ctx.moveTo(web.x, web.y); this.ctx.lineTo(web.x + web.w, web.y + web.h);
                this.ctx.moveTo(web.x + web.w, web.y); this.ctx.lineTo(web.x, web.y + web.h);
                this.ctx.stroke();
            });

            this.mushrooms.forEach(m => {
                this.ctx.fillStyle = m.type === 'shrink' ? '#ff2200' : '#a000ff';
                this.ctx.fillRect(m.x + 2, m.y, 10, 7);
                this.ctx.fillStyle = '#ffffff';
                this.ctx.fillRect(m.x + 4, m.y + 2, 2, 2);
                this.ctx.fillRect(m.x + 8, m.y + 2, 2, 2);
                this.ctx.fillStyle = '#ffdbac';
                this.ctx.fillRect(m.x + 5, m.y + 7, 4, 5);
            });

            this.candles.forEach(c => {
                this.ctx.fillStyle = '#e0d0b0';
                this.ctx.fillRect(c.x + 3, c.y + 5, 4, 9);
                this.ctx.fillStyle = (this.tickCount % 4 < 2) ? '#ffcc00' : '#ff4400';
                this.ctx.fillRect(c.x + 2, c.y + 1, 6, 4);
            });

            this.drawGalkin(this.player.x, this.player.y, this.player.dir, this.player.frame, this.player.debuffType);
            this.ghosts.forEach((g, idx) => this.drawGhost(g, idx));
        } 
        else if (this.state === 'GAMEOVER_SCREEN') {
            this.ctx.fillStyle = '#ff0033';
            this.ctx.font = 'bold 18px monospace';
            this.ctx.fillText('GAME OVER', 130, 110);
            this.ctx.fillStyle = '#ffffff';
            this.ctx.font = '11px monospace';
            this.ctx.fillText('ПОДВЕДЕНИЕ ИТОГОВ...', 130, 140);
        }
        else if (this.state === 'RESULTS') {
            this.renderResults();
        }
    }
}

/* =========================================================
   2. ОБЪЕКТ ABOUTBLOCK С ВСТРОЕННЫМ МОДАЛЬНЫМ ОКНОМ ИГРЫ
   ========================================================= */
window.AboutBlock = {
  assets: {
    trackAbout: 'https://github.com/Daniil160111/Woland-s-mansion/raw/refs/heads/main/%D0%9D%D0%B0%D1%81%D1%82%D1%80%D0%BE%D0%B9%D0%BA%D0%B8,%20%D0%B7%D0%B0%D0%BF%D0%B8%D1%81%D0%B8,%20%D0%BA%D0%BE%D0%BC%D0%BD%D0%B0%D1%82%D1%8B.mp3',
    sfxBtn: 'https://github.com/Daniil160111/Woland-s-mansion/raw/refs/heads/main/%D0%9A%D0%BD%D0%BE%D0%BF%D0%BA%D0%B0.wav'
  },

  styles: `
    .about-screen {
      position: fixed;
      top: 0; left: 0;
      width: 100vw;
      height: 100vh;
      overflow: hidden;
      background: #050200;
      user-select: none;
      -webkit-user-select: none;
      -webkit-tap-highlight-color: transparent;
      opacity: 0;
      transition: opacity 0.8s ease;
      z-index: 1000;
    }
    .about-screen.active-fade { opacity: 1 !important; }
    .about-screen.fade-out { opacity: 0 !important; transition: opacity 1.5s ease !important; pointer-events: none; }
    
    #about-canvas {
      position: absolute;
      bottom: 0;
      left: 0;
      width: 100%;
      height: 100%;
      z-index: 1;
      pointer-events: none;
    }
    
    .credits-viewport {
      position: relative;
      z-index: 2;
      width: 100%;
      height: 100%;
      overflow: hidden;
      touch-action: none;
      cursor: grab;
    }
    .credits-viewport:active { cursor: grabbing; }

    .credits-content {
      position: absolute;
      top: 0;
      left: 50%;
      transform: translateX(-50%) translateY(100vh);
      width: 88vw;
      max-width: 450px;
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 3.5vh;
      text-align: center;
      color: #ffe6d0;
      font-family: sans-serif;
      opacity: 0;
      transition: opacity 0.8s ease;
      pointer-events: auto;
      padding: 0 0 10vh 0;
      box-sizing: border-box;
    }
    .credits-content.visible { opacity: 1; }

    .credits-main-title {
      font-size: 2.2rem;
      font-weight: 900;
      color: #ffaa55;
      text-shadow: 0 0 18px rgba(255, 120, 0, 0.85);
      letter-spacing: 2px;
      margin-bottom: 2vh;
    }
    .credits-section-title {
      font-size: 1.3rem;
      font-weight: bold;
      color: #ff8800;
      border-bottom: 1.5px solid rgba(255, 136, 0, 0.4);
      padding-bottom: 6px;
      width: 100%;
      text-shadow: 0 0 10px rgba(255, 136, 0, 0.5);
    }
    .credits-role {
      font-size: 0.85rem;
      color: #ffcc99;
      text-transform: uppercase;
      letter-spacing: 1px;
      margin-bottom: 2px;
    }
    .credits-name {
      font-size: 1.2rem;
      font-weight: bold;
      color: #ffffff;
      text-shadow: 0 0 8px rgba(255, 255, 255, 0.6);
    }
    .credits-p {
      font-size: 0.95rem;
      line-height: 1.7;
      color: #ffd9cc;
      text-align: justify;
      text-justify: inter-word;
      padding: 0 4px;
    }
    .credits-highlight {
      color: #ffaa44;
      font-weight: bold;
    }

    .galkin-easter-btn {
      background: rgba(45, 15, 5, 0.9);
      border: 2px solid #ff8800;
      color: #ffaa55;
      padding: 14px 24px;
      border-radius: 14px;
      font-weight: bold;
      font-size: 1rem;
      cursor: pointer;
      box-shadow: 0 0 30px rgba(255, 100, 0, 0.2), inset 0 0 20px rgba(255, 100, 0, 0.1);
      transition: transform 0.15s, background 0.2s, box-shadow 0.2s;
      margin: 2vh 0;
      font-family: sans-serif;
      width: 100%;
      max-width: 300px;
    }
    .galkin-easter-btn:active {
      transform: scale(0.93);
      background: #ff8800;
      color: #000;
      box-shadow: 0 0 50px rgba(255, 100, 0, 0.5);
    }

    .credits-thanks {
      font-size: 2rem;
      font-weight: 900;
      color: #ffaa55;
      text-shadow: 0 0 30px rgba(255, 150, 0, 0.9);
      margin-top: 4vh;
      padding: 20px 0;
    }
    .credits-brand {
      font-size: 1rem;
      font-weight: bold;
      color: #888888;
      letter-spacing: 3px;
      margin-top: 1vh;
      margin-bottom: 5vh;
    }
    .credits-divider {
      width: 60%;
      height: 1px;
      background: linear-gradient(to right, transparent, rgba(255, 136, 0, 0.3), transparent);
      margin: 1vh 0;
    }

    /* СТИЛИ МОДАЛЬНОГО ОКНА МИНИ-ИГРЫ */
    .game-modal-overlay {
      position: fixed;
      top: 0; left: 0;
      width: 100vw; height: 100vh;
      background: rgba(0, 0, 0, 0.92);
      backdrop-filter: blur(8px);
      z-index: 2000;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      opacity: 0;
      pointer-events: none;
      transition: opacity 0.3s ease;
    }
    .game-modal-overlay.active {
      opacity: 1;
      pointer-events: auto;
    }

    .game-modal-container {
      position: relative;
      display: flex;
      flex-direction: column;
      align-items: center;
      background: #110914;
      border: 3px solid #ffaa55;
      box-shadow: 0 0 35px rgba(255, 136, 0, 0.4);
      border-radius: 18px;
      padding: 12px;
      max-width: 95vw;
    }

    .game-modal-close {
      position: absolute;
      top: -16px;
      right: -16px;
      width: 38px;
      height: 38px;
      background: #e60012;
      border: 2px solid #ffffff;
      color: #ffffff;
      border-radius: 50%;
      font-size: 20px;
      font-weight: bold;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 0 15px rgba(230, 0, 18, 0.6);
      z-index: 2001;
    }

    #snes-screen {
      width: 360px;
      height: 270px;
      max-width: 85vw;
      max-height: 55vh;
      background: #0f0a12;
      border: 2px solid #331a38;
      border-radius: 8px;
      image-rendering: pixelated;
    }

    /* Виртуальный геймпад D-Pad */
    .game-controls-panel {
      display: flex;
      justify-content: space-between;
      align-items: center;
      width: 100%;
      max-width: 360px;
      margin-top: 12px;
      gap: 10px;
    }

    .dpad-grid {
      display: grid;
      grid-template-columns: repeat(3, 38px);
      grid-template-rows: repeat(3, 38px);
      gap: 3px;
    }

    .dpad-btn {
      background: #2a1b30;
      border: 1px solid #ffaa55;
      color: #ffaa55;
      font-size: 14px;
      border-radius: 6px;
      display: flex;
      align-items: center;
      justify-content: center;
      user-select: none;
      cursor: pointer;
    }
    .dpad-btn:active {
      background: #ffaa55;
      color: #000000;
    }

    .action-btns {
      display: flex;
      gap: 10px;
    }

    .ctrl-btn {
      width: 50px;
      height: 50px;
      border-radius: 50%;
      background: #e60012;
      border: 2px solid #ffffff;
      color: #ffffff;
      font-weight: bold;
      font-size: 12px;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 4px 10px rgba(0,0,0,0.5);
    }
    .ctrl-btn:active {
      transform: scale(0.92);
      background: #ff4d4d;
    }
    .ctrl-btn-back {
      background: #444455;
    }
  `,

  audioObj: null,
  animId: null,
  scrollY: 0,
  speed: 0.7,
  isDragging: false,
  startY: 0,
  currentTranslateY: 0,
  isFinished: false,
  isTransitioning: false,
  thanksReached: false,
  gameInstance: null,
  isCreditsPaused: false,

  init() {
    this.isTransitioning = false;
    this.isFinished = false;
    this.thanksReached = false;
    this.isCreditsPaused = false;
    this.scrollY = window.innerHeight;

    if (this.audioObj) {
      try {
        this.audioObj.pause();
        this.audioObj.currentTime = 0;
      } catch(e) {}
      this.audioObj = null;
    }

    if (this.animId) {
      cancelAnimationFrame(this.animId);
      this.animId = null;
    }

    const app = document.getElementById('app') || document.body;
    app.innerHTML = '';

    const style = document.createElement('style');
    style.textContent = this.styles;
    document.head.appendChild(style);

    const container = document.createElement('div');
    container.className = 'about-screen';
    container.id = 'about-container';
    container.innerHTML = `
      <canvas id="about-canvas"></canvas>
      <div class="credits-viewport" id="credits-viewport">
        <div class="credits-content" id="credits-content">
          <div class="credits-main-title">WOLAND'S MANSION</div>

          <div>
            <div class="credits-role">🎮 Разработчик игры и автор всего проекта</div>
            <div class="credits-name">Даниил Власов</div>
          </div>

          <div>
            <div class="credits-role">💡 Автор идеи</div>
            <div class="credits-name">Андрей Скипидаров</div>
          </div>

          <div class="credits-divider"></div>

          <div class="credits-section-title">🎧 РЕВОЛЮЦИОННЫЙ ЗВУК</div>
          <div class="credits-p">
            В эту игру интегрирована эксклюзивная технология <span class="credits-highlight">Dolby™ Surround Pro Logic II Vertical Edition</span>, разработанная специально Даниилом Власовым. 
          </div>
          <div class="credits-p">
            Так как проект создан для мобильных устройств с вертикальной ориентацией экрана, стандартное стерео не могло передать необходимую глубину и объём звуковой сцены. Эта технология формирует уникальную трехмерную звуковую сцену, используя сложную цепочку DSP-эффектов, включая фазовое расширение, динамическую эквализацию и пространственную реверберацию.
          </div>
          <div class="credits-p">
            В основе системы лежит алгоритм <span class="credits-highlight">Vertical Dolby 100%</span>, который разделяет аудиосигнал на вертикальные каналы, создавая эффект объёмного звучания даже в обычных наушниках. Подобная система уникальна и не имеет аналогов в мобильном гейминге!
          </div>
          <div class="credits-p">
            Технология использует 8-канальную обработку сигнала с разделением на верхнюю и нижнюю полусферы, что позволяет создать эффект присутствия в трёхмерном пространстве. Каждый звук в игре проходит через этот алгоритм, включая музыку, звуковые эффекты и голосовые команды.
          </div>

          <div class="credits-divider"></div>

          <div class="credits-section-title">🏰 ИСТОЧНИКИ ВДОХНОВЕНИЯ</div>
          <div class="credits-p">
            В процессе создания были использованы материалы и вдохновение из легендарной серии игр от <span class="credits-highlight">Nintendo™</span>:
          </div>
          <div class="credits-p" style="text-align: center; line-height: 2;">
            👻 Luigi's Mansion (2001)<br>
            👻 Luigi's Mansion: Dark Moon (2013)<br>
            👻 Luigi's Mansion 3 (2019)
          </div>
          <div class="credits-p">
            Эти игры стали эталоном атмосферного хоррора с элементами юмора и невероятной проработки звукового дизайна. Мы вдохновлялись их подходом к созданию мистической, но в то же время уютной атмосферы.
          </div>
          <div class="credits-p">
            Особое внимание уделено детализации окружения — каждый предмет, каждый уголок особняка продуман до мелочей, чтобы игрок чувствовал себя частью этого таинственного мира.
          </div>

          <div class="credits-divider"></div>

          <div class="credits-section-title">⚡ ТЕХНОЛОГИИ</div>
          <div class="credits-p">
            Проект разработан с использованием чистого веб-стека <span class="credits-highlight">HTML5 / JavaScript / CSS3</span> специально для работы в высокопроизводительных контейнерах Web View без использования сторонних тяжелых движков и библиотек.
          </div>
          <div class="credits-p">
            Вся графика рендерится через <span class="credits-highlight">Canvas 2D API</span> с аппаратным ускорением, а аудио обрабатывается через <span class="credits-highlight">Web Audio API</span> с низкой задержкой, что обеспечивает плавную работу даже на бюджетных устройствах.
          </div>
          <div class="credits-p">
            Для обработки звука используется собственная библиотека DSP-эффектов, написанная вручную без использования сторонних решений. Это позволило достичь максимальной производительности и уникального звучания.
          </div>

          <div class="credits-divider"></div>

          <div class="credits-section-title">🌙 ОСОБЕННОСТИ ПРОЕКТА</div>
          <div class="credits-p">
            • Уникальная система объёмного звука Dolby Vertical<br>
            • Анимированные частицы дыма и свечения<br>
            • Интерактивные элементы с тактильной отдачей<br>
            • Динамическая смена времени суток в уровнях<br>
            • Собственная система достижений и рекордов<br>
            • Адаптивный интерфейс под любые экраны<br>
            • Оптимизация для слабых устройств
          </div>
          <div class="credits-p">
            Каждая деталь игры создана с любовью к деталям и уважением к классическим играм жанра. Мы стремились сделать проект, который будет радовать игроков не только геймплеем, но и визуальной и звуковой составляющей.
          </div>

          <button class="galkin-easter-btn" id="btn-galkin">🔮 Исследовать особняк Галкина</button>

          <div class="credits-divider"></div>

          <div class="credits-thanks" id="thanks-text">СПАСИБО ЧТО ВЫ С НАМИ!</div>
          <div class="credits-brand">✦ HTML Gaming™ ✦</div>
        </div>
      </div>

      <!-- ВСПЛЫВАЮЩЕЕ МОДАЛЬНОЕ ОКНО С ИГРОЙ -->
      <div class="game-modal-overlay" id="game-modal">
        <div class="game-modal-container">
          <button class="game-modal-close" id="modal-close-btn">✕</button>
          <canvas id="snes-screen" width="360" height="270"></canvas>
          <div class="game-controls-panel">
            <div class="dpad-grid">
              <div></div>
              <div class="dpad-btn" id="btn-u">▲</div>
              <div></div>
              <div class="dpad-btn" id="btn-l">◄</div>
              <div></div>
              <div class="dpad-btn" id="btn-r">►</div>
              <div></div>
              <div class="dpad-btn" id="btn-d">▼</div>
              <div></div>
            </div>
            <div class="action-btns">
              <button class="ctrl-btn ctrl-btn-back" id="btn-back">ESC</button>
              <button class="ctrl-btn" id="btn-ok">OK</button>
            </div>
          </div>
        </div>
      </div>
    `;
    app.appendChild(container);

    this.playMusic();
    this.startBubblesAnimation();

    setTimeout(() => {
      container.classList.add('active-fade');
    }, 50);

    setTimeout(() => {
      const content = document.getElementById('credits-content');
      if (content) {
        content.classList.add('visible');
        this.startCreditsScroll();
        this.bindDragEvents();
      }
    }, 1500);

    // Запуск мини-игры по кнопке
    document.getElementById('btn-galkin').addEventListener('click', (e) => {
      e.stopPropagation();
      e.preventDefault();
      this.playSfx(this.assets.sfxBtn);
      this.openGameModal();
    });

    // Закрытие модального окна игры
    document.getElementById('modal-close-btn').addEventListener('click', (e) => {
      e.stopPropagation();
      this.closeGameModal();
    });

    container.addEventListener('click', (e) => {
      if (e.target === container || e.target.id === 'about-container') {
        this.exitToMenu();
      }
    });
  },

  openGameModal() {
    const modal = document.getElementById('game-modal');
    if (!modal) return;
    
    modal.classList.add('active');
    
    // Приостанавливаем музыку титров и саму прокрутку
    this.pauseCredits();

    if (!this.gameInstance) {
      this.gameInstance = new GalkinMansionGame();
      this.gameInstance.init();
    }
  },

  closeGameModal() {
    const modal = document.getElementById('game-modal');
    if (modal) {
      modal.classList.remove('active');
    }

    if (this.gameInstance) {
      this.gameInstance.stop();
      this.gameInstance = null;
    }

    // Возобновляем музыку титров и прокрутку
    this.resumeCredits();
  },

  pauseCredits() {
    this.isCreditsPaused = true;
    
    // Приглушаем музыку титров
    if (this.audioObj) {
      this.audioObj.pause();
    }
  },

  resumeCredits() {
    this.isCreditsPaused = false;
    
    // Возобновляем музыку титров
    if (this.audioObj && !this.isTransitioning && !this.thanksReached) {
      this.audioObj.play().catch(() => {});
    }
  },

  startBubblesAnimation() {
    const canvas = document.getElementById('about-canvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    let width = canvas.width = window.innerWidth;
    let height = canvas.height = window.innerHeight;

    window.addEventListener('resize', () => {
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    });

    const bubbles = Array.from({ length: 35 }, () => ({
      x: Math.random() * width,
      y: height + Math.random() * 200,
      r: Math.random() * 25 + 5,
      vx: (Math.random() - 0.5) * 0.6,
      vy: -(Math.random() * 0.4 + 0.2),
      color: `hsla(${Math.floor(Math.random() * 40) + 10}, 80%, 60%, ${Math.random() * 0.25 + 0.15})`,
      wobble: Math.random() * Math.PI * 2,
      wobbleSpeed: (Math.random() - 0.5) * 0.025,
      glow: Math.random() * 0.5 + 0.3
    }));

    const render = () => {
      if (this.isTransitioning) {
        ctx.fillStyle = 'rgba(5, 2, 0, 0.3)';
        ctx.fillRect(0, 0, width, height);
        this.animId = requestAnimationFrame(render);
        return;
      }

      ctx.fillStyle = 'rgba(5, 2, 0, 0.12)';
      ctx.fillRect(0, 0, width, height);

      for (const b of bubbles) {
        b.wobble += b.wobbleSpeed;
        b.x += b.vx + Math.sin(b.wobble) * 0.25;
        b.y += b.vy;
        
        if (b.x - b.r < 0 || b.x + b.r > width) b.vx *= -1;
        
        if (b.y < -b.r * 2) {
          b.y = height + b.r;
          b.x = Math.random() * width;
          b.r = Math.random() * 25 + 5;
          b.vy = -(Math.random() * 0.4 + 0.2);
          b.color = `hsla(${Math.floor(Math.random() * 40) + 10}, 80%, 60%, ${Math.random() * 0.25 + 0.15})`;
        }

        ctx.save();
        
        const glow = ctx.createRadialGradient(b.x, b.y, 0, b.x, b.y, b.r * 2.5);
        glow.addColorStop(0, `rgba(255, 150, 50, ${b.glow * 0.05})`);
        glow.addColorStop(1, 'rgba(255, 150, 50, 0)');
        ctx.fillStyle = glow;
        ctx.beginPath();
        ctx.arc(b.x, b.y, b.r * 2.5, 0, Math.PI * 2);
        ctx.fill();
        
        const grad = ctx.createRadialGradient(
          b.x - b.r * 0.3, b.y - b.r * 0.3, 0,
          b.x, b.y, b.r
        );
        grad.addColorStop(0, `hsla(50, 90%, 75%, 0.3)`);
        grad.addColorStop(0.5, b.color);
        grad.addColorStop(1, `hsla(${Math.floor(Math.random() * 30) + 15}, 80%, 40%, 0.1)`);
        ctx.fillStyle = grad;
        ctx.shadowColor = `rgba(255, 100, 0, ${b.glow * 0.2})`;
        ctx.shadowBlur = 20;
        ctx.beginPath();
        ctx.arc(b.x, b.y, b.r, 0, Math.PI * 2);
        ctx.fill();
        
        ctx.shadowBlur = 0;
        ctx.beginPath();
        ctx.arc(b.x - b.r * 0.25, b.y - b.r * 0.3, b.r * 0.15, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(255,255,255,0.2)';
        ctx.fill();
        
        ctx.restore();
      }

      this.animId = requestAnimationFrame(render);
    };
    render();
  },

  startCreditsScroll() {
    const content = document.getElementById('credits-content');
    const thanksText = document.getElementById('thanks-text');
    if (!content) return;

    const scrollLoop = () => {
      if (this.isTransitioning || this.isFinished || this.isCreditsPaused) {
        if (!this.isTransitioning && !this.isFinished) {
          requestAnimationFrame(scrollLoop);
        }
        return;
      }

      if (!this.isDragging && !this.thanksReached) {
        this.scrollY -= this.speed;
        content.style.transform = `translateX(-50%) translateY(${this.scrollY}px)`;

        if (thanksText) {
          const rect = thanksText.getBoundingClientRect();
          const centerY = window.innerHeight / 2;

          if (rect.top <= centerY && rect.bottom >= centerY - 30) {
            this.thanksReached = true;
            this.isFinished = true;
            
            const offset = centerY - rect.top;
            this.scrollY += offset;
            content.style.transform = `translateX(-50%) translateY(${this.scrollY}px)`;

            setTimeout(() => {
              this.exitToMenu();
            }, 2000);
            return;
          }
        }
      }

      requestAnimationFrame(scrollLoop);
    };
    requestAnimationFrame(scrollLoop);
  },

  bindDragEvents() {
    const viewport = document.getElementById('credits-viewport');
    const content = document.getElementById('credits-content');
    if (!viewport || !content) return;

    const startDrag = (clientY) => {
      if (this.isFinished || this.isTransitioning || this.thanksReached || this.isCreditsPaused) return;
      this.isDragging = true;
      this.startY = clientY;
      this.currentTranslateY = this.scrollY;
    };

    const moveDrag = (clientY) => {
      if (!this.isDragging || this.isFinished || this.thanksReached || this.isCreditsPaused) return;
      const deltaY = clientY - this.startY;
      this.scrollY = this.currentTranslateY + deltaY;
      content.style.transform = `translateX(-50%) translateY(${this.scrollY}px)`;
    };

    const endDrag = () => {
      if (!this.isDragging) return;
      this.isDragging = false;
    };

    viewport.addEventListener('touchstart', (e) => startDrag(e.touches[0].clientY), { passive: true });
    viewport.addEventListener('touchmove', (e) => moveDrag(e.touches[0].clientY), { passive: true });
    viewport.addEventListener('touchend', endDrag, { passive: true });

    viewport.addEventListener('mousedown', (e) => startDrag(e.clientY));
    window.addEventListener('mousemove', (e) => moveDrag(e.clientY));
    window.addEventListener('mouseup', endDrag);
  },

  playMusic() {
    try {
      this.audioObj = new Audio(this.assets.trackAbout);
      this.audioObj.loop = true;
      
      const vol = window.settingsManager?.get('volume') || 80;
      this.audioObj.volume = vol / 100;
      this.audioObj.play().catch(() => {});
    } catch(e) {
      console.warn('Музыка не загрузилась');
    }
  },

  playSfx(url) {
    try {
      const sfx = new Audio(url);
      const vol = window.settingsManager?.get('volume') || 80;
      sfx.volume = vol / 100;
      sfx.play().catch(() => {});
    } catch(e) {}
  },

  exitToGalkin() {
    if (this.isTransitioning) return;
    this.isTransitioning = true;

    const container = document.getElementById('about-container');
    if (container) container.classList.add('fade-out');

    if (this.audioObj) {
      let vol = this.audioObj.volume;
      const fadeInterval = setInterval(() => {
        if (vol > 0.05) {
          vol -= 0.05;
          this.audioObj.volume = vol;
        } else {
          this.audioObj.volume = 0;
          this.audioObj.pause();
          clearInterval(fadeInterval);
        }
      }, 50);
    }

    setTimeout(() => {
      if (this.animId) {
        cancelAnimationFrame(this.animId);
        this.animId = null;
      }
      if (window.GalkinBlock && typeof window.GalkinBlock.init === 'function') {
        window.GalkinBlock.init();
      } else {
        console.warn('GalkinBlock не обнаружен в глобальной области видимости window');
      }
    }, 1500);
  },

  exitToMenu() {
    if (this.isTransitioning) return;
    
    if (this.gameInstance) {
      this.closeGameModal();
    }

    this.isTransitioning = true;

    const container = document.getElementById('about-container');
    if (container) container.classList.add('fade-out');

    if (this.audioObj) {
      let vol = this.audioObj.volume;
      const fadeInterval = setInterval(() => {
        if (vol > 0.05) {
          vol -= 0.05;
          this.audioObj.volume = vol;
        } else {
          this.audioObj.volume = 0;
          this.audioObj.pause();
          clearInterval(fadeInterval);
        }
      }, 50);
    }

    setTimeout(() => {
      if (this.animId) {
        cancelAnimationFrame(this.animId);
        this.animId = null;
      }
      if (window.MenuBlock && typeof window.MenuBlock.init === 'function') {
        window.MenuBlock.init();
      }
    }, 1500);
  }
};