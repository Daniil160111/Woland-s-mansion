window.TitleBlock = {
  assets: {
    bg: 'https://raw.githubusercontent.com/Daniil160111/Woland-s-mansion/refs/heads/main/title.jpg',
    name: 'https://raw.githubusercontent.com/Daniil160111/Woland-s-mansion/refs/heads/main/name.png',
    tap: 'https://raw.githubusercontent.com/Daniil160111/Woland-s-mansion/refs/heads/main/tap.png',
    company: 'https://raw.githubusercontent.com/Daniil160111/Woland-s-mansion/refs/heads/main/company.png',
    video: 'https://github.com/Daniil160111/Woland-s-mansion/raw/refs/heads/main/download.bin.mkv',
    trackMain: 'https://github.com/Daniil160111/Woland-s-mansion/raw/refs/heads/main/02.%20Title.mp3',
    trackRare: 'https://github.com/Daniil160111/Woland-s-mansion/raw/refs/heads/main/title2.wav',
    sfxBtn: 'https://github.com/Daniil160111/Woland-s-mansion/raw/refs/heads/main/%D0%9A%D0%BD%D0%BE%D0%BF%D0%BA%D0%B0.wav'
  },

  styles: `
    .title-screen {
      position: relative;
      width: 100vw;
      height: 100vh;
      overflow: hidden;
      background: #000;
      user-select: none;
      -webkit-user-select: none;
      -webkit-tap-highlight-color: transparent;
      opacity: 1;
      transition: opacity 1.5s ease-out;
    }

    .title-screen.fade-out {
      opacity: 0 !important;
      pointer-events: none;
    }

    .title-bg {
      position: absolute;
      top: 0; left: 0;
      width: 100%; height: 100%;
      object-fit: cover;
      opacity: 0;
      transition: opacity 2s linear;
      z-index: 1;
    }

    .title-video {
      position: absolute;
      top: 0; left: 0;
      width: 100%; height: 100%;
      object-fit: fill;
      opacity: 0;
      z-index: 2;
      pointer-events: none;
      transition: opacity 0.8s ease-in-out;
    }

    .title-logo {
      position: absolute;
      top: 43%;
      left: 50%;
      transform: translate(-50%, -50%) scaleY(0);
      transform-origin: bottom center;
      max-width: 85%;
      max-height: 40vh;
      object-fit: contain;
      opacity: 0;
      transition: transform 2s cubic-bezier(0.25, 1, 0.5, 1), opacity 1.5s ease-in-out, top 1s ease-in-out;
      z-index: 3;
      pointer-events: none;
    }

    .title-logo.active-accordion {
      opacity: 1 !important;
      transform: translate(-50%, -50%) scaleY(1) !important;
    }

    .title-logo.move-top {
      top: 15% !important;
    }

    .press-to-start {
      position: absolute;
      top: 68%;
      left: 50%;
      transform: translate(-50%, -50%);
      max-width: 90%;
      max-height: 20vh;
      object-fit: contain;
      opacity: 0;
      z-index: 4;
      pointer-events: none;
    }

    @keyframes pulseInOut {
      0% { opacity: 0.2; }
      50% { opacity: 1; }
      100% { opacity: 0.2; }
    }

    .press-to-start.animating {
      animation: pulseInOut 2.5s infinite ease-in-out;
    }

    .company-logo {
      position: absolute;
      bottom: 12vh;
      left: 50%;
      transform: translateX(-50%);
      width: 90vw;
      max-height: 10vh;
      object-fit: contain;
      opacity: 0;
      transition: opacity 2s linear;
      z-index: 4;
      pointer-events: none;
    }

    .easter-egg-window {
      position: absolute;
      top: 35.5%;
      left: 49.5%;
      transform: translate(-50%, -50%);
      width: 14vw;
      height: 7vh;
      border-radius: 50%;
      z-index: 99;
      cursor: pointer;
      outline: none;
      -webkit-tap-highlight-color: transparent;
    }

    .title-bg.instant-show,
    .company-logo.instant-show,
    .press-to-start.instant-show {
      transition: none !important;
      opacity: 1 !important;
    }

    .title-logo.instant-show {
      transition: none !important;
      opacity: 1 !important;
      transform: translate(-50%, -50%) scaleY(1) !important;
    }

    .active-fade {
      opacity: 1 !important;
    }
  `,

  audioObj: null,
  moveLogoTimer: null,
  isAudioStarted: false,
  isFullStateReached: false,
  isTransitioning: false,
  isVideoMode: false,
  audioTimer: null,
  fullStateTimer: null,
  selectedTrackUrl: null,
  restartTimer: null,
  videoEnded: false,

  init() {
    this.isAudioStarted = false;
    this.isFullStateReached = false;
    this.isTransitioning = false;
    this.isVideoMode = false;
    this.videoEnded = false;

    // Полный сброс предыдущего аудио
    if (this.audioObj) {
      try {
        this.audioObj.pause();
        this.audioObj.currentTime = 0;
        this.audioObj.onended = null;
      } catch (e) {}
      this.audioObj = null;
    }

    if (this.audioTimer) clearTimeout(this.audioTimer);
    if (this.fullStateTimer) clearTimeout(this.fullStateTimer);
    if (this.moveLogoTimer) clearTimeout(this.moveLogoTimer);
    if (this.restartTimer) clearTimeout(this.restartTimer);

    const app = document.getElementById('app') || document.body;
    app.innerHTML = '';

    // Шанс 5% на редкий трек, 95% на обычный
    const isRare = Math.random() < 0.05;
    this.selectedTrackUrl = isRare ? this.assets.trackRare : this.assets.trackMain;

    if (window.WolandEngine && window.WolandEngine.getModule('achievements')) {
      window.WolandEngine.getModule('achievements').unlock('FIRST_BOOT');
      if (isRare) {
        window.WolandEngine.getModule('achievements').unlock('RARE_TITLE');
      }
    }

    const style = document.createElement('style');
    style.textContent = this.styles;
    document.head.appendChild(style);

    const container = document.createElement('div');
    container.className = 'title-screen';
    container.id = 'title-container';
    container.innerHTML = `
      <img src="${this.assets.bg}" class="title-bg" id="bg-img">
      <video src="${this.assets.video}" class="title-video" id="title-video" playsinline preload="auto"></video>
      <img src="${this.assets.name}" class="title-logo" id="title-logo">
      <img src="${this.assets.tap}" class="press-to-start" id="press-start">
      <img src="${this.assets.company}" class="company-logo" id="company-logo">
      <div class="easter-egg-window" id="window-egg"></div>
    `;
    app.appendChild(container);

    const bgImg = document.getElementById('bg-img');
    const companyLogo = document.getElementById('company-logo');
    const titleLogo = document.getElementById('title-logo');
    const pressStart = document.getElementById('press-start');
    const windowEgg = document.getElementById('window-egg');
    const videoEl = document.getElementById('title-video');

    // Сброс видео
    if (videoEl) {
      videoEl.pause();
      videoEl.currentTime = 0;
      videoEl.style.opacity = '0';
      videoEl.onended = null;
    }

    setTimeout(() => {
      bgImg.classList.add('active-fade');
      companyLogo.classList.add('active-fade');
    }, 50);

    const audioDelay = isRare ? 2500 : 1500;
    this.audioTimer = setTimeout(() => {
      this.playTitleAudio();
    }, audioDelay);

    this.fullStateTimer = setTimeout(() => {
      titleLogo.classList.add('active-accordion');
      pressStart.classList.add('animating');
      this.isFullStateReached = true;
    }, 1800);

    container.addEventListener('click', (e) => {
      if (e.target === windowEgg || this.isTransitioning) return;

      // Клик во время проигрывания видео
      if (this.isVideoMode) {
        this.handleVideoEnd(true);
        return;
      }

      // Клик на титульном экране
      if (!this.isFullStateReached) {
        clearTimeout(this.audioTimer);
        clearTimeout(this.fullStateTimer);

        bgImg.classList.add('instant-show');
        companyLogo.classList.add('instant-show');
        titleLogo.classList.add('instant-show');
        pressStart.classList.add('instant-show');

        this.triggerExitToMenu(600);
      } else {
        this.triggerExitToMenu(0);
      }
    });

    let eggClicks = 0;
    windowEgg.addEventListener('click', (e) => {
      e.stopPropagation();
      e.stopImmediatePropagation();
      e.preventDefault();

      eggClicks++;

      if (window.WolandEngine && window.WolandEngine.getModule('settings')) {
        window.WolandEngine.getModule('settings').vibrate(25);
      }

      if (eggClicks === 10) {
        eggClicks = 0;
        if (window.WolandEngine && window.WolandEngine.getModule('achievements')) {
          window.WolandEngine.getModule('achievements').unlock('EASTER_SECRET_TAP');
        }
      }
    });
  },

  handleVideoEnd(wasClick = false) {
    if (this.isTransitioning) return;
    this.isTransitioning = true;

    const container = document.getElementById('title-container');
    const videoEl = document.getElementById('title-video');

    if (wasClick) {
      this.playClickSfx();
    }

    // Останавливаем видео
    if (videoEl) {
      videoEl.pause();
      videoEl.currentTime = 0;
      videoEl.style.opacity = '0';
      videoEl.onended = null;
    }

    // Затемняем всё за 1.5 секунды
    container.classList.add('fade-out');

    // Через 1.5 секунды перезапускаем блок
    this.restartTimer = setTimeout(() => {
      this.init();
    }, 1500);
  },

  playClickSfx() {
    const btnAudio = new Audio(this.assets.sfxBtn);
    btnAudio.volume = 1.0;
    btnAudio.play().catch(() => {});
  },

  playTitleAudio() {
    if (!this.isAudioStarted) {
      this.isAudioStarted = true;
      this.audioObj = new Audio(this.selectedTrackUrl);
      this.audioObj.loop = false;
      this.audioObj.volume = 1.0;

      if (window.WolandEngine && window.WolandEngine.getModule('settings')) {
        try {
          const setMod = window.WolandEngine.getModule('settings');
          const ctx = setMod.getAudioContext();
          if (ctx) {
            const source = ctx.createMediaElementSource(this.audioObj);
            setMod.connectAudioSource(source);
          }
        } catch (e) {}
      }

      this.audioObj.onended = () => {
        if (!this.isTransitioning) {
          // Ждём 1 секунду
          setTimeout(() => {
            this.startVideoSaver();
          }, 1000);
        }
      };

      this.audioObj.play().catch(() => {});
    }
  },

  startVideoSaver() {
    if (this.isTransitioning) return;

    const container = document.getElementById('title-container');
    const videoEl = document.getElementById('title-video');
    const titleLogo = document.getElementById('title-logo');
    const bgImg = document.getElementById('bg-img');

    this.isVideoMode = true;

    // Фон затемняется за 1.5 секунды
    if (bgImg) {
      bgImg.style.transition = 'opacity 1.5s ease-in-out';
      bgImg.style.opacity = '0';
    }

    if (videoEl) {
      videoEl.muted = false;
      videoEl.volume = 1.0;
      videoEl.currentTime = 0;
      
      // Видео появляется
      setTimeout(() => {
        videoEl.style.opacity = '1';
        videoEl.play().catch(() => {});
      }, 100);

      // Через 0.7 секунды после начала видео - название поднимается
      this.moveLogoTimer = setTimeout(() => {
        if (titleLogo) titleLogo.classList.add('move-top');
      }, 700);

      // Обработчик окончания видео
      videoEl.onended = () => {
        if (!this.isTransitioning && !this.videoEnded) {
          this.videoEnded = true;
          this.handleVideoEnd(false);
        }
      };
    }
  },

  fadeOutAudio() {
    if (!this.audioObj) return;
    let volume = this.audioObj.volume !== undefined ? this.audioObj.volume : 1.0;
    const fadeInterval = setInterval(() => {
      if (volume > 0.05) {
        volume -= 0.05;
        if (this.audioObj.volume !== undefined) this.audioObj.volume = volume;
      } else {
        if (this.audioObj.volume !== undefined) this.audioObj.volume = 0;
        if (typeof this.audioObj.pause === 'function') this.audioObj.pause();
        clearInterval(fadeInterval);
      }
    }, 50);
  },

  triggerExitToMenu(delayMs = 0) {
    if (this.isTransitioning) return;
    this.isTransitioning = true;

    this.playClickSfx();

    if (window.WolandEngine && window.WolandEngine.getModule('settings')) {
      window.WolandEngine.getModule('settings').vibrate(40);
    }

    setTimeout(() => {
      const container = document.getElementById('title-container');
      if (container) container.classList.add('fade-out');
      this.fadeOutAudio();

      setTimeout(() => {
        this.goToMenu();
      }, 1000);
    }, delayMs);
  },

  goToMenu() {
    if (window.MenuBlock && typeof window.MenuBlock.init === 'function') {
      window.MenuBlock.init();
    } else if (typeof window.initMenu === 'function') {
      window.initMenu();
    } else {
      console.log('Переход в menu.js');
    }
  }
};
