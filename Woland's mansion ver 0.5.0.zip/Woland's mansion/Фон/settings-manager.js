window.SettingsManager = class SettingsManager {
  constructor() {
    this.storageKey = 'woland_settings';
    this.data = this.load();
    this.applySettings();
  }

  getDefaults() {
    return {
      name: this.generateGuestName()
    };
  }

  generateGuestName() {
    return 'Игрок' + String(Math.floor(10000 + Math.random() * 90000));
  }

  load() {
    try {
      const saved = localStorage.getItem(this.storageKey);
      if (saved) {
        const parsed = JSON.parse(saved);
        return { ...this.getDefaults(), ...parsed };
      }
    } catch(e) {}
    return this.getDefaults();
  }

  save() {
    try {
      localStorage.setItem(this.storageKey, JSON.stringify(this.data));
    } catch(e) {}
  }

  get(key) {
    return this.data[key] !== undefined ? this.data[key] : this.getDefaults()[key];
  }

  set(key, value) {
    this.data[key] = value;
    this.save();
  }

  getName() {
    return this.get('name');
  }

  setName(name) {
    this.set('name', name || this.generateGuestName());
  }

  applySettings() {
    // Применяем настройки (пока только имя)
  }

  clearAllData() {
    try {
      localStorage.removeItem(this.storageKey);
      this.data = this.getDefaults();
      this.save();
      return true;
    } catch(e) {
      return false;
    }
  }
};

window.settingsManager = new window.SettingsManager();
