window.MenuBlock = {
  assets: {
    logo: 'https://raw.githubusercontent.com/Daniil160111/Woland-s-mansion/refs/heads/main/name.png',
    trackMenu: 'https://github.com/Daniil160111/Woland-s-mansion/raw/refs/heads/main/Menu.mp3',
    sfxBtn: 'https://github.com/Daniil160111/Woland-s-mansion/raw/refs/heads/main/%D0%9A%D0%BD%D0%BE%D0%BF%D0%BA%D0%B0.wav',
    sfxBack: 'https://github.com/Daniil160111/Woland-s-mansion/raw/refs/heads/main/%D0%9A%D0%BD%D0%BE%D0%BF%D0%BA%D0%B0%20%D0%BD%D0%B0%D0%B7%D0%B0%D0%B4.wav'
  },

  styles: `
    .menu-screen {
      position: fixed;
      top: 0; left: 0;
      width: 100vw;
      height: 100vh;
      overflow: hidden;
      background: #000000;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: flex-start;
      box-sizing: border-box;
      user-select: none;
      -webkit-user-select: none;
      -webkit-tap-highlight-color: transparent;
      opacity: 0;
      transition: opacity 0.8s ease-in-out;
      z-index: 1000;
    }

    #smoke-canvas {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      z-index: 1;
      pointer-events: none;
    }

    .menu-content {
      position: relative;
      z-index: 2;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: flex-start;
      width: 100%;
      height: 100%;
      box-sizing: border-box;
    }

    .menu-screen.active-fade {
      opacity: 1 !important;
    }

    .menu-screen.fade-out {
      opacity: 0 !important;
      pointer-events: none;
    }

    .menu-logo-container {
      height: 28vh;
      width: 100%;
      display: flex;
      align-items: center;
      justify-content: center;
      padding-top: 2vh;
      box-sizing: border-box;
    }

    .menu-logo {
      max-width: 85%;
      max-height: 22vh;
      object-fit: contain;
      filter: drop-shadow(0 0 16px rgba(0, 0, 0, 0.95));
    }

    .menu-list {
      height: 57vh;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: space-evenly;
      width: 100%;
      margin-bottom: 15vh;
      box-sizing: border-box;
    }

    .menu-btn {
      background: rgba(12, 10, 26, 0.78);
      border: 1.8px solid rgba(110, 90, 180, 0.5);
      color: #e2d9f3;
      font-family: sans-serif;
      font-size: 1.25rem;
      font-weight: bold;
      letter-spacing: 1px;
      padding: 13px 0;
      width: 75vw;
      max-width: 320px;
      text-align: center;
      border-radius: 12px;
      box-shadow: 0 4px 14px rgba(0, 0, 0, 0.65), inset 0 0 10px rgba(110, 90, 180, 0.25);
      transition: transform 0.15s ease, background 0.2s ease, border-color 0.2s ease, box-shadow 0.2s ease;
      cursor: pointer;
    }

    .menu-btn:active {
      transform: scale(0.95);
      background: rgba(70, 45, 130, 0.85);
      border-color: #bfa0ff;
      box-shadow: 0 0 18px rgba(191, 160, 255, 0.6);
      color: #ffffff;
    }

    .menu-btn.back-btn {
      margin-top: 1.5vh;
      border-color: rgba(180, 70, 70, 0.5);
      background: rgba(28, 10, 15, 0.78);
      color: #f3d9d9;
    }

    .menu-btn.back-btn:active {
      background: rgba(140, 35, 45, 0.85);
      border-color: #ff8080;
      box-shadow: 0 0 18px rgba(255, 128, 128, 0.6);
    }
  `,

  audioObj: null,
  animId: null,
  isTransitioning: false,

  init() {
    this.isTransitioning = false;

    // Останавливаем аудио
    if (this.audioObj) {
      try {
        this.audioObj.pause();
        this.audioObj.currentTime = 0;
      } catch (e) {}
      this.audioObj = null;
    }

    // Останавливаем анимацию
    if (this.animId) {
      cancelAnimationFrame(this.animId);
      this.animId = null;
    }

    // Очищаем app
    const app = document.getElementById('app') || document.body;
    app.innerHTML = '';

    // Удаляем старые стили MenuBlock
    const oldStyles = document.querySelectorAll('style');
    oldStyles.forEach(style => {
      if (style.textContent.includes('.menu-screen')) {
        style.remove();
      }
    });

    // Добавляем стили
    const style = document.createElement('style');
    style.textContent = this.styles;
    document.head.appendChild(style);

    // Создаем контейнер
    const container = document.createElement('div');
    container.className = 'menu-screen';
    container.id = 'menu-container';
    container.innerHTML = `
      <canvas id="smoke-canvas"></canvas>
      <div class="menu-content">
        <div class="menu-logo-container">
          <img src="${this.assets.logo}" class="menu-logo" alt="Woland's Mansion">
        </div>
        
        <div class="menu-list">
          <div class="menu-btn" id="btn-play">Играть</div>
          <div class="menu-btn" id="btn-records">Рекорды</div>
          <div class="menu-btn" id="btn-settings">Настройки</div>
          <div class="menu-btn" id="btn-about">Об игре</div>
          <div class="menu-btn back-btn" id="btn-title">На титульный экран</div>
        </div>
      </div>
    `;
    app.appendChild(container);

    // Запускаем анимацию и музыку
    this.startSmokeAnimation();
    this.playMenuAudio();

    // Показываем меню
    setTimeout(() => {
      container.classList.add('active-fade');
    }, 50);

    // Обработчики кнопок
    document.getElementById('btn-play').addEventListener('click', () => {
      this.navigate('rooms', this.assets.sfxBtn);
    });

    document.getElementById('btn-records').addEventListener('click', () => {
      this.navigate('records', this.assets.sfxBtn);
    });

    document.getElementById('btn-settings').addEventListener('click', () => {
      this.navigate('settings', this.assets.sfxBtn);
    });

    document.getElementById('btn-about').addEventListener('click', () => {
      this.navigate('about', this.assets.sfxBtn);
    });

    document.getElementById('btn-title').addEventListener('click', () => {
      this.navigate('title', this.assets.sfxBack);
    });
  },

  startSmokeAnimation() {
    const canvas = document.getElementById('smoke-canvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');

    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    window.addEventListener('resize', () => {
      if (!canvas) return;
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    });

    const particles = [];
    const particleCount = 35;

    class SmokeParticle {
      constructor() {
        this.reset(true);
      }

      reset(initial = false) {
        this.x = Math.random() * width;
        this.y = initial ? Math.random() * height : height + Math.random() * 100;
        this.radius = Math.random() * 140 + 80;
        this.vx = (Math.random() - 0.5) * 0.4;
        this.vy = -(Math.random() * 0.6 + 0.3);
        this.alpha = 0;
        this.maxAlpha = Math.random() * 0.25 + 0.12;
        this.growRate = Math.random() * 0.08 + 0.04;
        const hues = [220, 240, 260, 275];
        this.hue = hues[Math.floor(Math.random() * hues.length)];
      }

      update() {
        this.x += this.vx + Math.sin(this.y * 0.005) * 0.3;
        this.y += this.vy;
        this.radius += this.growRate;

        if (this.y > height * 0.7) {
          if (this.alpha < this.maxAlpha) this.alpha += 0.003;
        } else {
          this.alpha -= 0.0015;
        }

        if (this.alpha <= 0 || this.y < -this.radius * 2) {
          this.reset();
        }
      }

      draw() {
        ctx.save();
        ctx.globalAlpha = Math.max(0, this.alpha);
        const grad = ctx.createRadialGradient(
          this.x, this.y, 0,
          this.x, this.y, this.radius
        );
        grad.addColorStop(0, `hsla(${this.hue}, 80%, 45%, 0.8)`);
        grad.addColorStop(0.5, `hsla(${this.hue}, 70%, 25%, 0.3)`);
        grad.addColorStop(1, 'rgba(0, 0, 0, 0)');

        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      }
    }

    for (let i = 0; i < particleCount; i++) {
      particles.push(new SmokeParticle());
    }

    const loop = () => {
      ctx.fillStyle = 'rgba(0, 0, 0, 0.2)';
      ctx.fillRect(0, 0, width, height);

      particles.forEach((p) => {
        p.update();
        p.draw();
      });

      this.animId = requestAnimationFrame(loop);
    };

    loop();
  },

  playSfx(sfxUrl) {
    const sfx = new Audio(sfxUrl);
    sfx.volume = 1.0;
    sfx.play().catch(() => {});
  },

  playMenuAudio() {
    try {
      this.audioObj = new Audio(this.assets.trackMenu);
      this.audioObj.loop = true;
      this.audioObj.volume = 1.0;

      if (window.WolandEngine && window.WolandEngine.getModule('settings')) {
        try {
          const setMod = window.WolandEngine.getModule('settings');
          const ctx = setMod.getAudioContext();
          if (ctx) {
            const source = ctx.createMediaElementSource(this.audioObj);
            setMod.connectAudioSource(source);
          }
        } catch (e) {}
      }

      this.audioObj.play().catch(() => {});
    } catch(e) {
      console.warn('Ошибка воспроизведения музыки меню');
    }
  },

  fadeOutAudio() {
    if (!this.audioObj) return;
    let volume = this.audioObj.volume || 1.0;
    const fadeInterval = setInterval(() => {
      if (volume > 0.05) {
        volume -= 0.05;
        this.audioObj.volume = volume;
      } else {
        this.audioObj.volume = 0;
        this.audioObj.pause();
        clearInterval(fadeInterval);
      }
    }, 40);
  },

  navigate(target, sfxUrl) {
    if (this.isTransitioning) return;
    this.isTransitioning = true;

    this.playSfx(sfxUrl);

    if (window.WolandEngine && window.WolandEngine.getModule('settings')) {
      window.WolandEngine.getModule('settings').vibrate(35);
    }

    const container = document.getElementById('menu-container');
    if (container) container.classList.add('fade-out');

    this.fadeOutAudio();

    setTimeout(() => {
      if (this.animId) {
        cancelAnimationFrame(this.animId);
        this.animId = null;
      }

      // Удаляем старые стили перед переходом
      const oldStyles = document.querySelectorAll('style');
      oldStyles.forEach(style => {
        if (style.textContent.includes('.menu-screen')) {
          style.remove();
        }
      });

      switch (target) {
        case 'rooms':
          if (window.RoomsBlock && typeof window.RoomsBlock.init === 'function') {
            window.RoomsBlock.init();
          } else {
            console.log('Переход в rooms.js');
          }
          break;

        case 'records':
          if (window.RecordsBlock && typeof window.RecordsBlock.init === 'function') {
            window.RecordsBlock.init();
          } else {
            console.log('Переход в records.js');
          }
          break;

        case 'settings':
          if (window.SettingsBlock && typeof window.SettingsBlock.init === 'function') {
            window.SettingsBlock.init();
          } else {
            console.log('Переход в settings.js');
          }
          break;

        case 'about':
          if (window.AboutBlock && typeof window.AboutBlock.init === 'function') {
            window.AboutBlock.init();
          } else {
            console.log('Переход в about.js');
          }
          break;

        case 'title':
          if (window.TitleBlock && typeof window.TitleBlock.init === 'function') {
            window.TitleBlock.init();
          } else {
            console.log('Переход в title.js');
          }
          break;
      }
    }, 800);
  }
};
