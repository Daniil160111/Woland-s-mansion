window.LogoBlock = {
  styles: `
    #logo-screen {
      width: 100vw;
      height: 100vh;
      background-color: #000;
      display: flex;
      justify-content: center;
      align-items: center;
      position: relative;
      overflow: hidden;
      font-family: 'Courier New', monospace;
      color: #fff;
      text-align: center;
    }

    .logo-img {
      max-width: 90vw;
      max-height: 80vh;
      object-fit: contain;
      opacity: 0;
      transition: opacity 1.5s ease-in-out;
      margin-bottom: 20vh; 
    }

    .logo-img.disclaimer-fit {
      max-width: 90vw;
      max-height: 90vh;
      object-fit: contain;
      margin-bottom: 0;
    }

    .logo-img.visible {
      opacity: 1;
    }

    #dolby-img {
      transform: translateX(-5%);
      filter: brightness(1.25) contrast(1.15) saturate(1.2);
    }

    #nintendo-img {
      margin-bottom: 25vh;
      transform: scale(1.2); 
      filter: brightness(1.25) contrast(1.15) saturate(1.2);
    }

    .loader-container {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 12px;
      padding: 20px;
      min-width: 280px;
    }

    .loader-title {
      font-size: 1.1rem;
      color: #ffcc88;
      letter-spacing: 1px;
      text-shadow: 0 0 15px rgba(255, 150, 50, 0.3);
      font-weight: bold;
    }

    .loader-bar-bg {
      width: 100%;
      height: 10px;
      background: #1a0f1a;
      border: 1px solid #442244;
      border-radius: 6px;
      overflow: hidden;
      box-shadow: inset 0 0 10px rgba(0,0,0,0.8);
    }

    .loader-bar-fill {
      width: 0%;
      height: 100%;
      background: linear-gradient(90deg, #ff4400, #ff8800, #ffcc00);
      border-radius: 6px;
      transition: width 0.25s ease;
      box-shadow: 0 0 20px rgba(255, 100, 0, 0.4);
    }

    .loader-stats {
      display: flex;
      justify-content: space-between;
      width: 100%;
      font-size: 0.75rem;
      color: #aa99aa;
      letter-spacing: 0.5px;
    }

    .loader-stats .left { text-align: left; }
    .loader-stats .right { text-align: right; }

    .loader-sub {
      font-size: 0.7rem;
      color: #665566;
      margin-top: 2px;
      letter-spacing: 0.3px;
    }

    .loader-check {
      font-size: 0.85rem;
      color: #88ddbb;
      opacity: 0;
      transition: opacity 0.5s ease;
      margin-top: 5px;
    }

    .loader-check.visible {
      opacity: 1;
    }
  `,

  // Все ресурсы из всех блоков
  assets: {
    // Logo
    disclaimerImg: "https://raw.githubusercontent.com/Daniil160111/Woland-s-mansion/refs/heads/main/%D0%94%D0%B8%D1%81%D0%BA%D0%BB%D0%B5%D0%B9%D0%BC%D0%B5%D1%80.jpg",
    dolbyImg: "https://raw.githubusercontent.com/Daniil160111/Woland-s-mansion/refs/heads/main/Dolby.jpg",
    nintendoImg: "https://raw.githubusercontent.com/Daniil160111/Woland-s-mansion/refs/heads/main/Nintendo.jpg",
    buttonSound: "https://github.com/Daniil160111/Woland-s-mansion/raw/refs/heads/main/%D0%9A%D0%BD%D0%BE%D0%BF%D0%BA%D0%B0.wav",
    nintendoSound: "https://github.com/Daniil160111/Woland-s-mansion/raw/refs/heads/main/Logo.mp3",
    menuMusic: "https://github.com/Daniil160111/Woland-s-mansion/raw/refs/heads/main/Menu.mp3",
    
    // Title
    titleBg: "https://raw.githubusercontent.com/Daniil160111/Woland-s-mansion/refs/heads/main/title.jpg",
    titleName: "https://raw.githubusercontent.com/Daniil160111/Woland-s-mansion/refs/heads/main/name.png",
    titleTap: "https://raw.githubusercontent.com/Daniil160111/Woland-s-mansion/refs/heads/main/tap.png",
    titleCompany: "https://raw.githubusercontent.com/Daniil160111/Woland-s-mansion/refs/heads/main/company.png",
    titleVideo: "https://github.com/Daniil160111/Woland-s-mansion/raw/refs/heads/main/download.bin.mkv",
    titleTrackMain: "https://github.com/Daniil160111/Woland-s-mansion/raw/refs/heads/main/02.%20Title.mp3",
    titleTrackRare: "https://github.com/Daniil160111/Woland-s-mansion/raw/refs/heads/main/title2.wav",
    titleSfxBtn: "https://github.com/Daniil160111/Woland-s-mansion/raw/refs/heads/main/%D0%9A%D0%BD%D0%BE%D0%BF%D0%BA%D0%B0.wav",
    
    // Menu
    menuLogo: "https://raw.githubusercontent.com/Daniil160111/Woland-s-mansion/refs/heads/main/name.png",
    menuTrack: "https://github.com/Daniil160111/Woland-s-mansion/raw/refs/heads/main/Menu.mp3",
    menuSfxBtn: "https://github.com/Daniil160111/Woland-s-mansion/raw/refs/heads/main/%D0%9A%D0%BD%D0%BE%D0%BF%D0%BA%D0%B0.wav",
    menuSfxBack: "https://github.com/Daniil160111/Woland-s-mansion/raw/refs/heads/main/%D0%9A%D0%BD%D0%BE%D0%BF%D0%BA%D0%B0%20%D0%BD%D0%B0%D0%B7%D0%B0%D0%B4.wav",
    
    // Settings
    settingsBg: "https://raw.githubusercontent.com/Daniil160111/Woland-s-mansion/refs/heads/main/title.jpg",
    settingsTrack: "https://github.com/Daniil160111/Woland-s-mansion/raw/refs/heads/main/%D0%9D%D0%B0%D1%81%D1%82%D1%80%D0%BE%D0%B9%D0%BA%D0%B8,%20%D0%B7%D0%B0%D0%BF%D0%B8%D1%81%D0%B8,%20%D0%BA%D0%BE%D0%BC%D0%BD%D0%B0%D1%82%D1%8B.mp3",
    settingsSfxSave: "https://github.com/Daniil160111/Woland-s-mansion/raw/refs/heads/main/%D0%9A%D0%BD%D0%BE%D0%BF%D0%BA%D0%B0.wav",
    settingsSfxBack: "https://github.com/Daniil160111/Woland-s-mansion/raw/refs/heads/main/%D0%9A%D0%BD%D0%BE%D0%BF%D0%BA%D0%B0%20%D0%BD%D0%B0%D0%B7%D0%B0%D0%B4.wav",
    settingsSfxClear: "https://github.com/Daniil160111/Woland-s-mansion/raw/refs/heads/main/%D0%A1%D0%B1%D1%80%D0%BE%D1%81.mp3",
    
    // About
    aboutTrack: "https://github.com/Daniil160111/Woland-s-mansion/raw/refs/heads/main/%D0%9D%D0%B0%D1%81%D1%82%D1%80%D0%BE%D0%B9%D0%BA%D0%B8,%20%D0%B7%D0%B0%D0%BF%D0%B8%D1%81%D0%B8,%20%D0%BA%D0%BE%D0%BC%D0%BD%D0%B0%D1%82%D1%8B.mp3",
    aboutSfxBtn: "https://github.com/Daniil160111/Woland-s-mansion/raw/refs/heads/main/%D0%9A%D0%BD%D0%BE%D0%BF%D0%BA%D0%B0.wav"
  },

  cache: {},
  totalBytes: 0,
  loadedBytes: 0,
  startTime: 0,
  isVerifying: false,
  audioObjects: [],
  isTransitioning: false,

  render() {
    return `
      <style>${this.styles}</style>
      <div id="logo-screen">
        <div class="loader-container" id="loader-box">
          <div class="loader-title">Идёт загрузка дополнительных ресурсов игры...</div>
          <div class="loader-bar-bg">
            <div class="loader-bar-fill" id="loader-fill"></div>
          </div>
          <div class="loader-stats">
            <span class="left" id="loader-percent">0%</span>
            <span class="right" id="loader-time">Осталось примерно: --:--</span>
          </div>
          <div class="loader-stats">
            <span class="left" id="loader-size">0 МБ / 0 МБ</span>
            <span class="right" id="loader-speed">0 МБ/с</span>
          </div>
          <div class="loader-check" id="loader-check">✓ Проверка целостности файлов...</div>
        </div>
      </div>
    `;
  },

  init() {
    this.isTransitioning = false;
    this.audioObjects = [];
    
    const app = document.getElementById('app');
    app.innerHTML = this.render();

    this.cache = {};
    this.loadedBytes = 0;
    this.totalBytes = 0;
    this.startTime = Date.now();
    this.isVerifying = false;

    // Убеждаемся что AudioManager инициализирован
    if (window.AudioManager) {
      if (!window.AudioManager.isInitialized) {
        window.AudioManager.init();
      }
      console.log('🎵 AudioManager доступен в LogoBlock');
    } else {
      console.warn('⚠️ AudioManager не найден, звуки могут не работать');
    }

    // Собираем все URL ресурсов
    const urls = Object.values(this.assets).filter(url => typeof url === 'string' && url.startsWith('http'));
    
    // Получаем размеры файлов (HEAD запросы)
    this.fetchTotalSize(urls);
  },

  async fetchTotalSize(urls) {
    const updateInterval = setInterval(() => this.updateTimeDisplay(), 1000);
    
    try {
      const headPromises = urls.map(url => 
        fetch(url, { method: 'HEAD' })
          .then(res => {
            const size = parseInt(res.headers.get('content-length') || '0');
            return { url, size };
          })
          .catch(() => ({ url, size: 0 }))
      );
      
      const results = await Promise.all(headPromises);
      this.totalBytes = results.reduce((sum, r) => sum + r.size, 0);
      
      if (this.totalBytes === 0) {
        this.totalBytes = 35 * 1024 * 1024;
      }
      
      this.downloadAll(urls);
      
    } catch (e) {
      this.totalBytes = 35 * 1024 * 1024;
      this.downloadAll(urls);
    }
    
    this._timeInterval = updateInterval;
  },

  async downloadAll(urls) {
    let loaded = 0;
    const total = urls.length;
    
    const updateProgress = () => {
      const percent = Math.min(100, Math.floor((this.loadedBytes / this.totalBytes) * 100));
      const fill = document.getElementById('loader-fill');
      const percentEl = document.getElementById('loader-percent');
      const sizeEl = document.getElementById('loader-size');
      
      if (fill) fill.style.width = `${percent}%`;
      if (percentEl) percentEl.textContent = `${percent}%`;
      
      const loadedMB = (this.loadedBytes / (1024 * 1024)).toFixed(1);
      const totalMB = (this.totalBytes / (1024 * 1024)).toFixed(1);
      if (sizeEl) sizeEl.textContent = `${loadedMB} МБ / ${totalMB} МБ`;
    };
    
    const downloadPromises = urls.map(async (url) => {
      try {
        const response = await fetch(url);
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        
        const reader = response.body.getReader();
        let received = 0;
        
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          
          received += value.length;
          this.loadedBytes += value.length;
          
          if (received % (100 * 1024) < value.length) {
            updateProgress();
            this.updateSpeedDisplay();
          }
        }
        
        const blob = new Blob([await response.arrayBuffer()]);
        const objectUrl = URL.createObjectURL(blob);
        this.cache[url] = objectUrl;
        
        loaded++;
        updateProgress();
        this.updateSpeedDisplay();
        
      } catch (e) {
        console.warn('Failed to load:', url, e);
        loaded++;
        this.cache[url] = url;
        updateProgress();
      }
    });
    
    await Promise.allSettled(downloadPromises);
    
    if (this._timeInterval) {
      clearInterval(this._timeInterval);
      this._timeInterval = null;
    }
    
    const percentEl = document.getElementById('loader-percent');
    if (percentEl) percentEl.textContent = '100%';
    
    this.startVerification();
  },

  updateTimeDisplay() {
    const elapsed = (Date.now() - this.startTime) / 1000;
    const progress = this.totalBytes > 0 ? this.loadedBytes / this.totalBytes : 0;
    
    if (progress < 0.01) return;
    
    const speed = this.loadedBytes / elapsed;
    const remainingBytes = this.totalBytes - this.loadedBytes;
    let remainingSeconds = speed > 0 ? remainingBytes / speed : 0;
    
    if (remainingSeconds > 3600) remainingSeconds = 3600;
    if (remainingSeconds < 1) remainingSeconds = 0;
    
    const mins = Math.floor(remainingSeconds / 60);
    const secs = Math.floor(remainingSeconds % 60);
    
    const timeEl = document.getElementById('loader-time');
    if (timeEl) {
      if (remainingSeconds < 1) {
        timeEl.textContent = 'Осталось примерно: --:--';
      } else {
        timeEl.textContent = `Осталось примерно: ${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
      }
    }
    
    this.updateSpeedDisplay();
  },

  updateSpeedDisplay() {
    const elapsed = (Date.now() - this.startTime) / 1000;
    if (elapsed < 0.5) return;
    
    const speed = this.loadedBytes / elapsed;
    const speedMB = speed / (1024 * 1024);
    
    const speedEl = document.getElementById('loader-speed');
    if (speedEl) {
      speedEl.textContent = `${speedMB.toFixed(1)} МБ/с`;
    }
  },

  startVerification() {
    this.isVerifying = true;
    const checkEl = document.getElementById('loader-check');
    if (checkEl) checkEl.classList.add('visible');
    
    const startVerify = Date.now();
    const verifyInterval = setInterval(() => {
      const progress = Math.min(100, ((Date.now() - startVerify) / 1500) * 100);
      const fill = document.getElementById('loader-fill');
      if (fill) {
        fill.style.width = `${Math.min(100, progress)}%`;
      }
      
      const percentEl = document.getElementById('loader-percent');
      if (percentEl) {
        percentEl.textContent = `${Math.floor(Math.min(100, progress))}%`;
      }
      
      if (progress >= 100) {
        clearInterval(verifyInterval);
        if (checkEl) checkEl.textContent = '✓ Все файлы проверены успешно!';
        
        setTimeout(() => {
          this.showDisclaimer();
        }, 500);
      }
    }, 50);
  },

  // ==================== ВОСПРОИЗВЕДЕНИЕ ЗВУКОВ ЧЕРЕЗ AUDIOMANAGER ====================
  
  /**
   * Гарантированное воспроизведение звука через AudioManager
   */
  playSound(url, volume = 0.7) {
    if (!url) return null;
    
    // Если есть AudioManager - используем его
    if (window.AudioManager && window.AudioManager.isInitialized) {
      console.log(`🔊 LogoBlock: воспроизведение через AudioManager`);
      return window.AudioManager.playGuaranteed(url, volume);
    }
    
    // Fallback - прямое воспроизведение
    try {
      const audio = new Audio(url);
      audio.volume = Math.min(1, volume);
      
      // Пытаемся разблокировать через AudioContext если есть
      if (window.AudioManager && window.AudioManager.audioCtx) {
        try {
          const source = window.AudioManager.audioCtx.createMediaElementSource(audio);
          source.connect(window.AudioManager.audioCtx.destination);
        } catch (e) {
          // Если не получилось - просто играем
        }
      }
      
      const promise = audio.play();
      if (promise) {
        promise.catch(() => {
          console.warn(`⚠️ Не удалось воспроизвести: ${url}`);
        });
      }
      
      this.audioObjects.push(audio);
      return audio;
    } catch (e) {
      console.warn(`⚠️ Ошибка воспроизведения: ${url}`, e);
      return null;
    }
  },

  /**
   * Воспроизведение звука с задержкой (для синхронизации с анимацией)
   */
  playSoundDelayed(url, delay, volume = 0.7) {
    setTimeout(() => {
      this.playSound(url, volume);
    }, delay);
  },

  // ==================== ПОКАЗ ЭКРАНОВ ====================

  showDisclaimer() {
    const screen = document.getElementById('logo-screen');
    screen.innerHTML = `
      <style>${this.styles}</style>
      <img id="disclaimer-img" class="logo-img disclaimer-fit visible" src="${this.assets.disclaimerImg}" alt="Disclaimer">
    `;

    let clicked = false;
    const disclaimerImg = document.getElementById('disclaimer-img');

    const handleClick = () => {
      if (clicked || this.isTransitioning) return;
      clicked = true;
      this.isTransitioning = true;

      // Воспроизводим звук кнопки через AudioManager
      this.playSound(this.assets.buttonSound, 0.5);

      disclaimerImg.classList.remove('visible');
      setTimeout(() => {
        this.isTransitioning = false;
        this.showDolby();
      }, 1500);
    };

    // Добавляем обработчики на клик и тач
    screen.addEventListener('click', handleClick, { once: true });
    screen.addEventListener('touchstart', handleClick, { once: true });
  },

  showDolby() {
    const screen = document.getElementById('logo-screen');
    screen.innerHTML = `
      <style>${this.styles}</style>
      <img id="dolby-img" class="logo-img" src="${this.assets.dolbyImg}" alt="Dolby">
    `;

    const dolbyImg = document.getElementById('dolby-img');
    requestAnimationFrame(() => dolbyImg.classList.add('visible'));

    // Воспроизводим звук Dolby (если есть)
    setTimeout(() => {
      dolbyImg.classList.remove('visible');
      setTimeout(() => {
        this.showNintendo();
      }, 1500);
    }, 1500);
  },

  showNintendo() {
    const screen = document.getElementById('logo-screen');
    screen.innerHTML = `
      <style>${this.styles}</style>
      <img id="nintendo-img" class="logo-img visible" style="transition: opacity 1.5s ease-in-out;" src="${this.assets.nintendoImg}" alt="Nintendo">
    `;

    const nintendoImg = document.getElementById('nintendo-img');

    // Воспроизводим звук Nintendo через AudioManager с задержкой для синхронизации
    console.log('🔊 LogoBlock: воспроизведение Nintendo звука');
    
    // Пробуем через AudioManager
    if (window.AudioManager && window.AudioManager.isInitialized) {
      // Создаём audio и воспроизводим с гарантией
      const audio = window.AudioManager.playGuaranteed(this.assets.nintendoSound, 0.8);
      
      // Если не получилось - пробуем прямой способ
      if (!audio) {
        try {
          const fallbackAudio = new Audio(this.assets.nintendoSound);
          fallbackAudio.volume = 0.8;
          fallbackAudio.play().catch(() => {});
          this.audioObjects.push(fallbackAudio);
        } catch (e) {}
      }
    } else {
      // Fallback без AudioManager
      try {
        const audio = new Audio(this.assets.nintendoSound);
        audio.volume = 0.8;
        audio.play().catch(() => {});
        this.audioObjects.push(audio);
      } catch (e) {}
    }

    setTimeout(() => {
      nintendoImg.classList.remove('visible');
      setTimeout(() => {
        // Останавливаем все звуки перед переходом
        this.stopAllSounds();
        this.goToTitle();
      }, 1500);
    }, 1500);
  },

  stopAllSounds() {
    this.audioObjects.forEach(audio => {
      try {
        audio.pause();
        audio.currentTime = 0;
      } catch (e) {}
    });
    this.audioObjects = [];
    
    // Если есть AudioManager - останавливаем всё через него
    if (window.AudioManager) {
      window.AudioManager.stopAllSounds();
    }
  },

  goToTitle() {
    if (window.TitleBlock && typeof window.TitleBlock.init === 'function') {
      window.TitleBlock.init();
    } else {
      console.error("Ошибка: TitleBlock не найден.");
    }
  }
};